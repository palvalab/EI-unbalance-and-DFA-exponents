close all
clear all
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%                   Full Cohort DFA Results                                 %%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load('L:\nttk-data2\palva\Madrid\Full Cohort\Figures Codes\Standalone figure codes\DFA_fEI_estimates.mat')

for k=1:3
    for i=1:size(temp_exp{k},3)
        avg_exp_subj{k}(i,:) = nanmean(temp_exp{k}(:,:,i));
    end
    for i=1:size(temp_fEI{k},3)
        avg_fEI_subj{k}(i,:) = nanmean(temp_fEI{k}(:,:,i));
    end
end


%%%%%%%%%%%%%%%%%%% Network wise average %%%%%%%%%%%%%%%%%%%%%%

band = {[1:5],[6:9],[10:15],[16:23],[24:32]};
bnd_name = {'delta','theta','alpha','beta','gamma'};
load('L:\nttk-data2\palva\Madrid\Analysis Results\Network_7_numbers.mat')

sig_avg_net_exp={};
for k=1:3
    for bnd=2:size(band,2)
        for i=1:size(Netwroks_7.number,1)
            temp_net = [];
                temp_net = Netwroks_7.number(i,:);
                temp_net = temp_net((temp_net ~= -1));
                sig_avg_net_exp{k}{bnd}{i}(:,1) = nanmean(nanmean(temp_exp{k}(temp_net,band{bnd},:),2),1);
        end
    end
end

for bnd=2:size(band,2)
    for i=1:size(Netwroks_7.number,1)
        data=[];
        data(:,1) = sig_avg_net_exp{1}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\DFA\Whole brain Average\7 Network Data\NC\DFA_' Netwroks_7.name{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)
        data=[];
        data(:,1) = sig_avg_net_exp{2}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\DFA\Whole brain Average\7 Network Data\SCD\DFA_' Netwroks_7.name{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)
        data=[];
        data(:,1) = sig_avg_net_exp{3}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\DFA\Whole brain Average\7 Network Data\MCI\DFA_' Netwroks_7.name{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)           
    end
end

load('wilcoxn_DFA_FDR_Sig_05.mat');

display('SCD vs NC')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Cntrl vs SCD %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for bnd=2:size(band,2)
    sig_per_freq_scd =[]
    for i=1:size(band{bnd},2)
        sig_per_freq_scd(1,i) = numel(find(SCD_fdr_sig_05(:,band{bnd}(i))==1))/400;
    end
    [val,idx]=max(sig_per_freq_scd)

    for i=1:size(band{bnd},2)
        SCD_fdr_sig_05(:,band{bnd}(i)) = SCD_fdr_sig_05(:,band{bnd}(i)).*SCD_fdr_sig_05(:,band{bnd}(idx));
    end
end
SCD_fdr_sig_05(find(SCD_fdr_sig_05==0))=NaN;
sig_NC_SCD_exp={};
temp_exp_sig={};
for k=1:2
    for sb=1:size(temp_exp{k},3)
        ttmp =[];
        ttmp(:,:) = temp_exp{k}(:,:,sb);
        temp_exp_sig{k}(:,:,sb) = ttmp(:,:).*SCD_fdr_sig_05;
    end
    for bnd=2:size(band,2)
        for i=1:size(Netwroks_7.number,1)
            temp_net = [];
            temp_net = Netwroks_7.number(i,:);
            temp_net = temp_net((temp_net ~= -1));
            sig_NC_SCD_exp{k}{bnd}{i}(:,1) = nanmean(nanmean(temp_exp_sig{k}(temp_net,band{bnd},:),2),1);
        end
    end
end

for bnd=2:size(band,2)
    for i=1:size(Netwroks_7.number,1)
        data=[];
        data(:,1) = sig_NC_SCD_exp{1}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\DFA\Significant Diff Parcel\7 Network Data\NC vs SCD\NC\DFA_Sig_' Netwroks_7.name{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)
        data=[];
        data(:,1) = sig_NC_SCD_exp{2}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\DFA\Significant Diff Parcel\7 Network Data\NC vs SCD\SCD\DFA_Sig_' Netwroks_7.name{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)           
    end
end


display('MCI vs NC')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Cntrl vs MCI %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for bnd=2:size(band,2)
    sig_per_freq_MCI =[];
    for i=1:size(band{bnd},2)
        sig_per_freq_MCI(1,i) = numel(find(MCI_fdr_sig_05(:,band{bnd}(i))==1))/400;
    end
    [val,idx]=max(sig_per_freq_MCI)

    for i=1:size(band{bnd},2)
        MCI_fdr_sig_05(:,band{bnd}(i)) = MCI_fdr_sig_05(:,band{bnd}(i)).*MCI_fdr_sig_05(:,band{bnd}(idx));
    end
end
MCI_fdr_sig_05(find(MCI_fdr_sig_05==0))=NaN;
sig_NC_MCI_exp={};
temp_exp_sig={};
for k=1:2:3
    for sb=1:size(temp_exp{k},3)
        ttmp =[];
        ttmp(:,:) = temp_exp{k}(:,:,sb);
        temp_exp_sig{k}(:,:,sb) = ttmp(:,:).*MCI_fdr_sig_05;
    end
    for bnd=2:size(band,2)
        for i=1:size(Netwroks_7.number,1)
            temp_net = [];
            temp_net = Netwroks_7.number(i,:);
            temp_net = temp_net((temp_net ~= -1));
            sig_NC_MCI_exp{k}{bnd}{i}(:,1) = nanmean(nanmean(temp_exp_sig{k}(temp_net,band{bnd},:),2),1);
        end
    end
end

for bnd=2:size(band,2)
    for i=1:size(Netwroks_7.number,1)
        data=[];
        data(:,1) = sig_NC_MCI_exp{1}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\DFA\Significant Diff Parcel\7 Network Data\NC vs MCI\NC\DFA_Sig_' Netwroks_7.name{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)
        data=[];
        data(:,1) = sig_NC_MCI_exp{3}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\DFA\Significant Diff Parcel\7 Network Data\NC vs MCI\MCI\DFA_Sig_' Netwroks_7.name{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)           
    end
end

display('       SCD vs MCI')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% SCD vs MCI %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for bnd=2:size(band,2)
    sig_per_freq_SM =[];
    for i=1:size(band{bnd},2)
        sig_per_freq_SM(1,i) = numel(find(SM_fdr_sig_05(:,band{bnd}(i))==1))/400;
    end
    [val,idx]=max(sig_per_freq_SM)

    for i=1:size(band{bnd},2)
        SM_fdr_sig_05(:,band{bnd}(i)) = SM_fdr_sig_05(:,band{bnd}(i)).*SM_fdr_sig_05(:,band{bnd}(idx));
    end
end
SM_fdr_sig_05(find(SM_fdr_sig_05==0))=NaN;
sig_SCD_MCI_exp={};
temp_exp_sig={};
for k=2:3
    for sb=1:size(temp_exp{k},3)
        ttmp =[];
        ttmp(:,:) = temp_exp{k}(:,:,sb);
        temp_exp_sig{k}(:,:,sb) = ttmp(:,:).*SM_fdr_sig_05;
    end
    for bnd=2:size(band,2)
        for i=1:size(Netwroks_7.number,1)
            temp_net = [];
            temp_net = Netwroks_7.number(i,:);
            temp_net = temp_net((temp_net ~= -1));
            sig_SCD_MCI_exp{k}{bnd}{i}(:,1) = nanmean(nanmean(temp_exp_sig{k}(temp_net,band{bnd},:),2),1);
        end
    end
end

for bnd=2:size(band,2)
    for i=1:size(Netwroks_7.number,1)
        data=[];
        data(:,1) = sig_SCD_MCI_exp{2}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\DFA\Significant Diff Parcel\7 Network Data\SCD vs MCI\SCD\DFA_Sig_' Netwroks_7.name{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)
        data=[];
        data(:,1) = sig_SCD_MCI_exp{3}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\DFA\Significant Diff Parcel\7 Network Data\SCD vs MCI\MCI\DFA_Sig_' Netwroks_7.name{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)           
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%% 17 Network wise average %%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



bnd_name = {'delta','theta','alpha','beta','gamma'};
load('L:\nttk-data2\palva\Madrid\Analysis Results\Network_17_numbers.mat')
Netwroks_17(find(Netwroks_17 < 202)) = Netwroks_17(find(Netwroks_17 < 202))-1;
Netwroks_17(find(Netwroks_17 > 202)) = Netwroks_17(find(Netwroks_17 > 202))-2;
sig_avg_net_exp={};
for k=1:3
    for bnd=2:size(band,2)
        for i=1:size(Netwroks_17,1)
            temp_net = [];
            temp_net = Netwroks_17(i,:);
            temp_net = temp_net((temp_net ~= -1));
            sig_avg_net_exp{k}{bnd}{i}(:,1) = nanmean(nanmean(temp_exp{k}(temp_net,band{bnd},:),2),1);
        end
    end
end

Network_17_labels = {};
a=1;
for i=1:(size(label,1)/2)-1
    if i~= 1 && i~= 202
        aa = find(label{i} == '_');
        tmp_lbl = label{i}(aa(2)+1:aa(3)-1);
        if isempty(Network_17_labels)
            Network_17_labels{a} = tmp_lbl;
            a=a+1;
        elseif ~strcmp(Network_17_labels{a-1},tmp_lbl)
            Network_17_labels{a} = tmp_lbl;
            a=a+1;
        end
    end
end

for bnd=2:size(band,2)
    for i=1:size(Netwroks_17,1)
        data=[];
        data(:,1) = sig_avg_net_exp{1}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\DFA\Whole brain Average\17 Network Data\NC\DFA_' Network_17_labels{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)
        data=[];
        data(:,1) = sig_avg_net_exp{2}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\DFA\Whole brain Average\17 Network Data\SCD\DFA_' Network_17_labels{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)
        data=[];
        data(:,1) = sig_avg_net_exp{3}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\DFA\Whole brain Average\17 Network Data\MCI\DFA_' Network_17_labels{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)           
    end
end

load('wilcoxn_DFA_FDR_Sig_05.mat');

display('SCD vs NC')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Cntrl vs SCD %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for bnd=2:size(band,2)
    sig_per_freq_scd =[]
    for i=1:size(band{bnd},2)
        sig_per_freq_scd(1,i) = numel(find(SCD_fdr_sig_05(:,band{bnd}(i))==1))/400;
    end
    [val,idx]=max(sig_per_freq_scd)

    for i=1:size(band{bnd},2)
        SCD_fdr_sig_05(:,band{bnd}(i)) = SCD_fdr_sig_05(:,band{bnd}(i)).*SCD_fdr_sig_05(:,band{bnd}(idx));
    end
end
SCD_fdr_sig_05(find(SCD_fdr_sig_05==0))=NaN;
sig_NC_SCD_exp={};
temp_exp_sig={};
for k=1:2
    for sb=1:size(temp_exp{k},3)
        ttmp =[];
        ttmp(:,:) = temp_exp{k}(:,:,sb);
        temp_exp_sig{k}(:,:,sb) = ttmp(:,:).*SCD_fdr_sig_05;
    end
    for bnd=2:size(band,2)
        for i=1:size(Netwroks_17,1)
            temp_net = [];
            temp_net = Netwroks_17(i,:);
            temp_net = temp_net((temp_net ~= -1));
            sig_NC_SCD_exp{k}{bnd}{i}(:,1) = nanmean(nanmean(temp_exp{k}(temp_net,band{bnd},:),2),1);
        end
    end
end

for bnd=2:size(band,2)
    for i=1:size(Netwroks_17,1)
        data=[];
        data(:,1) = sig_NC_SCD_exp{1}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\DFA\Significant Diff Parcel\17 Network Data\NC vs SCD\NC\DFA_Sig_' Network_17_labels{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)
        data=[];
        data(:,1) = sig_NC_SCD_exp{2}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\DFA\Significant Diff Parcel\17 Network Data\NC vs SCD\SCD\DFA_Sig_' Network_17_labels{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)           
    end
end


display('MCI vs NC')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Cntrl vs MCI %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for bnd=2:size(band,2)
    sig_per_freq_MCI =[];
    for i=1:size(band{bnd},2)
        sig_per_freq_MCI(1,i) = numel(find(MCI_fdr_sig_05(:,band{bnd}(i))==1))/400;
    end
    [val,idx]=max(sig_per_freq_MCI)

    for i=1:size(band{bnd},2)
        MCI_fdr_sig_05(:,band{bnd}(i)) = MCI_fdr_sig_05(:,band{bnd}(i)).*MCI_fdr_sig_05(:,band{bnd}(idx));
    end
end
MCI_fdr_sig_05(find(MCI_fdr_sig_05==0))=NaN;
sig_NC_MCI_exp={};
temp_exp_sig={};
for k=1:2:3
    for sb=1:size(temp_exp{k},3)
        ttmp =[];
        ttmp(:,:) = temp_exp{k}(:,:,sb);
        temp_exp_sig{k}(:,:,sb) = ttmp(:,:).*MCI_fdr_sig_05;
    end
    for bnd=2:size(band,2)
        for i=1:size(Netwroks_17,1)
            temp_net = [];
            temp_net = Netwroks_17(i,:);
            temp_net = temp_net((temp_net ~= -1));
            sig_NC_MCI_exp{k}{bnd}{i}(:,1) = nanmean(nanmean(temp_exp{k}(temp_net,band{bnd},:),2),1);
        end
    end
end

for bnd=2:size(band,2)
    for i=1:size(Netwroks_17,1)
        data=[];
        data(:,1) = sig_NC_MCI_exp{1}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\DFA\Significant Diff Parcel\17 Network Data\NC vs MCI\NC\DFA_Sig_' Network_17_labels{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)
        data=[];
        data(:,1) = sig_NC_MCI_exp{3}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\DFA\Significant Diff Parcel\17 Network Data\NC vs MCI\MCI\DFA_Sig_' Network_17_labels{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)           
    end
end

display('       SCD vs MCI')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% SCD vs MCI %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for bnd=2:size(band,2)
    sig_per_freq_SM =[];
    for i=1:size(band{bnd},2)
        sig_per_freq_SM(1,i) = numel(find(SM_fdr_sig_05(:,band{bnd}(i))==1))/400;
    end
    [val,idx]=max(sig_per_freq_SM)

    for i=1:size(band{bnd},2)
        SM_fdr_sig_05(:,band{bnd}(i)) = SM_fdr_sig_05(:,band{bnd}(i)).*SM_fdr_sig_05(:,band{bnd}(idx));
    end
end
SM_fdr_sig_05(find(SM_fdr_sig_05==0))=NaN;
sig_SCD_MCI_exp={};
temp_exp_sig={};
for k=2:3
    for sb=1:size(temp_exp{k},3)
        ttmp =[];
        ttmp(:,:) = temp_exp{k}(:,:,sb);
        temp_exp_sig{k}(:,:,sb) = ttmp(:,:).*SM_fdr_sig_05;
    end
    for bnd=2:size(band,2)
        for i=1:size(Netwroks_17,1)
            temp_net = [];
            temp_net = Netwroks_17(i,:);
            temp_net = temp_net((temp_net ~= -1));
            sig_SCD_MCI_exp{k}{bnd}{i}(:,1) = nanmean(nanmean(temp_exp{k}(temp_net,band{bnd},:),2),1);
        end
    end
end

for bnd=2:size(band,2)
    for i=1:size(Netwroks_17,1)
        data=[];
        data(:,1) = sig_SCD_MCI_exp{2}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\DFA\Significant Diff Parcel\17 Network Data\SCD vs MCI\SCD\DFA_Sig_' Network_17_labels{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)
        data=[];
        data(:,1) = sig_SCD_MCI_exp{3}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\DFA\Significant Diff Parcel\17 Network Data\SCD vs MCI\MCI\DFA_Sig_' Network_17_labels{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)           
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


close all
clear all
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%                   Full Cohort fE/I Results                                 %%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load('L:\nttk-data2\palva\Madrid\Full Cohort\Figures Codes\Standalone figure codes\DFA_fEI_estimates.mat')

for k=1:3
    for i=1:size(temp_exp{k},3)
        avg_exp_subj{k}(i,:) = nanmean(temp_exp{k}(:,:,i));
    end
    for i=1:size(temp_fEI{k},3)
        avg_fEI_subj{k}(i,:) = nanmean(temp_fEI{k}(:,:,i));
    end
end


temp_exp1 = temp_exp;    
temp_exp  =  temp_fEI;
avg_exp_subj1 = avg_exp_subj;
avg_exp_subj = avg_fEI_subj;

%%%%%%%%%%%%%%%%%%% Network wise average %%%%%%%%%%%%%%%%%%%%%%

band = {[1:5],[6:9],[10:15],[16:23],[24:32]};
bnd_name = {'delta','theta','alpha','beta','gamma'};
load('L:\nttk-data2\palva\Madrid\Analysis Results\Network_7_numbers.mat')

sig_avg_net_exp={};
for k=1:3
    for bnd=2:size(band,2)
        for i=1:size(Netwroks_7.number,1)
            temp_net = [];
                temp_net = Netwroks_7.number(i,:);
                temp_net = temp_net((temp_net ~= -1));
                sig_avg_net_exp{k}{bnd}{i}(:,1) = nanmean(nanmean(temp_exp{k}(temp_net,band{bnd},:),2),1);
        end
    end
end

for bnd=2:size(band,2)
    for i=1:size(Netwroks_7.number,1)
        data=[];
        data(:,1) = sig_avg_net_exp{1}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\fEI\Whole brain Average\7 Network Data\NC\fEI_' Netwroks_7.name{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)
        data=[];
        data(:,1) = sig_avg_net_exp{2}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\fEI\Whole brain Average\7 Network Data\SCD\fEI_' Netwroks_7.name{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)
        data=[];
        data(:,1) = sig_avg_net_exp{3}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\fEI\Whole brain Average\7 Network Data\MCI\fEI_' Netwroks_7.name{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)           
    end
end

load('L:\nttk-data2\palva\Madrid\Full Cohort\Figures Codes\Between group fEI stats\Full Cohort\wilcoxn_FDR_Sig_05.mat');

display('SCD vs NC')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Cntrl vs SCD %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for bnd=2:size(band,2)
    sig_per_freq_scd =[]
    for i=1:size(band{bnd},2)
        sig_per_freq_scd(1,i) = numel(find(SCD_fdr_sig_05(:,band{bnd}(i))==1))/400;
    end
    [val,idx]=max(sig_per_freq_scd)

    for i=1:size(band{bnd},2)
        SCD_fdr_sig_05(:,band{bnd}(i)) = SCD_fdr_sig_05(:,band{bnd}(i)).*SCD_fdr_sig_05(:,band{bnd}(idx));
    end
end
SCD_fdr_sig_05(find(SCD_fdr_sig_05==0))=NaN;
sig_NC_SCD_exp={};
temp_exp_sig={};
for k=1:2
    for sb=1:size(temp_exp{k},3)
        ttmp =[];
        ttmp(:,:) = temp_exp{k}(:,:,sb);
        temp_exp_sig{k}(:,:,sb) = ttmp(:,:).*SCD_fdr_sig_05;
    end
    for bnd=2:size(band,2)
        for i=1:size(Netwroks_7.number,1)
            temp_net = [];
            temp_net = Netwroks_7.number(i,:);
            temp_net = temp_net((temp_net ~= -1));
            sig_NC_SCD_exp{k}{bnd}{i}(:,1) = nanmean(nanmean(temp_exp_sig{k}(temp_net,band{bnd},:),2),1);
        end
    end
end

for bnd=2:size(band,2)
    for i=1:size(Netwroks_7.number,1)
        data=[];
        data(:,1) = sig_NC_SCD_exp{1}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\fEI\Significant Diff Parcel\7 Network Data\NC vs SCD\NC\fEI_Sig_' Netwroks_7.name{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)
        data=[];
        data(:,1) = sig_NC_SCD_exp{2}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\fEI\Significant Diff Parcel\7 Network Data\NC vs SCD\SCD\fEI_Sig_' Netwroks_7.name{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)           
    end
end


display('MCI vs NC')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Cntrl vs MCI %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for bnd=2:size(band,2)
    sig_per_freq_MCI =[];
    for i=1:size(band{bnd},2)
        sig_per_freq_MCI(1,i) = numel(find(MCI_fdr_sig_05(:,band{bnd}(i))==1))/400;
    end
    [val,idx]=max(sig_per_freq_MCI)

    for i=1:size(band{bnd},2)
        MCI_fdr_sig_05(:,band{bnd}(i)) = MCI_fdr_sig_05(:,band{bnd}(i)).*MCI_fdr_sig_05(:,band{bnd}(idx));
    end
end
MCI_fdr_sig_05(find(MCI_fdr_sig_05==0))=NaN;
sig_NC_MCI_exp={};
temp_exp_sig={};
for k=1:2:3
    for sb=1:size(temp_exp{k},3)
        ttmp =[];
        ttmp(:,:) = temp_exp{k}(:,:,sb);
        temp_exp_sig{k}(:,:,sb) = ttmp(:,:).*MCI_fdr_sig_05;
    end
    for bnd=2:size(band,2)
        for i=1:size(Netwroks_7.number,1)
            temp_net = [];
            temp_net = Netwroks_7.number(i,:);
            temp_net = temp_net((temp_net ~= -1));
            sig_NC_MCI_exp{k}{bnd}{i}(:,1) = nanmean(nanmean(temp_exp_sig{k}(temp_net,band{bnd},:),2),1);
        end
    end
end

for bnd=2:size(band,2)
    for i=1:size(Netwroks_7.number,1)
        data=[];
        data(:,1) = sig_NC_MCI_exp{1}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\fEI\Significant Diff Parcel\7 Network Data\NC vs MCI\NC\fEI_Sig_' Netwroks_7.name{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)
        data=[];
        data(:,1) = sig_NC_MCI_exp{3}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\fEI\Significant Diff Parcel\7 Network Data\NC vs MCI\MCI\fEI_Sig_' Netwroks_7.name{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)           
    end
end

display('       SCD vs MCI')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% SCD vs MCI %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for bnd=2:size(band,2)
    sig_per_freq_SM =[];
    for i=1:size(band{bnd},2)
        sig_per_freq_SM(1,i) = numel(find(SM_fdr_sig_05(:,band{bnd}(i))==1))/400;
    end
    [val,idx]=max(sig_per_freq_SM)

    for i=1:size(band{bnd},2)
        SM_fdr_sig_05(:,band{bnd}(i)) = SM_fdr_sig_05(:,band{bnd}(i)).*SM_fdr_sig_05(:,band{bnd}(idx));
    end
end
SM_fdr_sig_05(find(SM_fdr_sig_05==0))=NaN;
sig_SCD_MCI_exp={};
temp_exp_sig={};
for k=2:3
    for sb=1:size(temp_exp{k},3)
        ttmp =[];
        ttmp(:,:) = temp_exp{k}(:,:,sb);
        temp_exp_sig{k}(:,:,sb) = ttmp(:,:).*SM_fdr_sig_05;
    end
    for bnd=2:size(band,2)
        for i=1:size(Netwroks_7.number,1)
            temp_net = [];
            temp_net = Netwroks_7.number(i,:);
            temp_net = temp_net((temp_net ~= -1));
            sig_SCD_MCI_exp{k}{bnd}{i}(:,1) = nanmean(nanmean(temp_exp_sig{k}(temp_net,band{bnd},:),2),1);
        end
    end
end

for bnd=2:size(band,2)
    for i=1:size(Netwroks_7.number,1)
        data=[];
        data(:,1) = sig_SCD_MCI_exp{2}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\fEI\Significant Diff Parcel\7 Network Data\SCD vs MCI\SCD\fEI_Sig_' Netwroks_7.name{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)
        data=[];
        data(:,1) = sig_SCD_MCI_exp{3}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\fEI\Significant Diff Parcel\7 Network Data\SCD vs MCI\MCI\fEI_Sig_' Netwroks_7.name{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)           
    end
end


load('MTL_Volumes.mat')
nl1={'lh-Hip','rh-Hip','lh-Ent','rh-Ent','lh-ParaHip','rh-ParaHip'};

for i=1:size(temp_volume{1},2)
    data=[];
    data(:,1) = temp_volume{1}(:,i);
        fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\MTL Volumes\NC\Vol_' nl1{i}  '.csv'];
%     csvwrite(fname,data)
    data=[];
    data(:,1) = temp_volume{2}(:,i);
        fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\MTL Volumes\SCD\Vol_' nl1{i}  '.csv'];
%     csvwrite(fname,data)
    data=[];
    data(:,1) = temp_volume{3}(:,i);
        fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\MTL Volumes\MCI\Vol_' nl1{i}  '.csv'];
%     csvwrite(fname,data)           
end





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%% 17 Network wise average %%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



band = {[1:5],[6:9],[10:15],[16:23],[24:32]};
bnd_name = {'delta','theta','alpha','beta','gamma'};
load('L:\nttk-data2\palva\Madrid\Analysis Results\Network_17_numbers.mat')
Netwroks_17(find(Netwroks_17 < 202)) = Netwroks_17(find(Netwroks_17 < 202))-1;
Netwroks_17(find(Netwroks_17 > 202)) = Netwroks_17(find(Netwroks_17 > 202))-2;
sig_avg_net_exp={};
for k=1:3
    for bnd=2:size(band,2)
        for i=1:size(Netwroks_17,1)
            temp_net = [];
            temp_net = Netwroks_17(i,:);
            temp_net = temp_net((temp_net ~= -1));
            sig_avg_net_exp{k}{bnd}{i}(:,1) = nanmean(nanmean(temp_exp{k}(temp_net,band{bnd},:),2),1);
        end
    end
end

Network_17_labels = {};
a=1;
for i=1:(size(label,1)/2)-1
    if i~= 1 && i~= 202
        aa = find(label{i} == '_');
        tmp_lbl = label{i}(aa(2)+1:aa(3)-1);
        if isempty(Network_17_labels)
            Network_17_labels{a} = tmp_lbl;
            a=a+1;
        elseif ~strcmp(Network_17_labels{a-1},tmp_lbl)
            Network_17_labels{a} = tmp_lbl;
            a=a+1;
        end
    end
end

for bnd=2:size(band,2)
    for i=1:size(Netwroks_17,1)
        data=[];
        data(:,1) = sig_avg_net_exp{1}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\fEI\Whole brain Average\17 Network Data\NC\fEI_' Network_17_labels{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)
        data=[];
        data(:,1) = sig_avg_net_exp{2}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\fEI\Whole brain Average\17 Network Data\SCD\fEI_' Network_17_labels{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)
        data=[];
        data(:,1) = sig_avg_net_exp{3}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\fEI\Whole brain Average\17 Network Data\MCI\fEI_' Network_17_labels{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)           
    end
end

load('L:\nttk-data2\palva\Madrid\Full Cohort\Figures Codes\Between group fEI stats\Full Cohort\wilcoxn_FDR_Sig_05.mat');

display('SCD vs NC')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Cntrl vs SCD %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for bnd=2:size(band,2)
    sig_per_freq_scd =[]
    for i=1:size(band{bnd},2)
        sig_per_freq_scd(1,i) = numel(find(SCD_fdr_sig_05(:,band{bnd}(i))==1))/400;
    end
    [val,idx]=max(sig_per_freq_scd)

    for i=1:size(band{bnd},2)
        SCD_fdr_sig_05(:,band{bnd}(i)) = SCD_fdr_sig_05(:,band{bnd}(i)).*SCD_fdr_sig_05(:,band{bnd}(idx));
    end
end
SCD_fdr_sig_05(find(SCD_fdr_sig_05==0))=NaN;
sig_NC_SCD_exp={};
temp_exp_sig={};
for k=1:2
    for sb=1:size(temp_exp{k},3)
        ttmp =[];
        ttmp(:,:) = temp_exp{k}(:,:,sb);
        temp_exp_sig{k}(:,:,sb) = ttmp(:,:).*SCD_fdr_sig_05;
    end
    for bnd=2:size(band,2)
        for i=1:size(Netwroks_17,1)
            temp_net = [];
            temp_net = Netwroks_17(i,:);
            temp_net = temp_net((temp_net ~= -1));
            sig_NC_SCD_exp{k}{bnd}{i}(:,1) = nanmean(nanmean(temp_exp{k}(temp_net,band{bnd},:),2),1);
        end
    end
end

for bnd=2:size(band,2)
    for i=1:size(Netwroks_17,1)
        data=[];
        data(:,1) = sig_NC_SCD_exp{1}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\fEI\Significant Diff Parcel\17 Network Data\NC vs SCD\NC\fEI_Sig_' Network_17_labels{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)
        data=[];
        data(:,1) = sig_NC_SCD_exp{2}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\fEI\Significant Diff Parcel\17 Network Data\NC vs SCD\SCD\fEI_Sig_' Network_17_labels{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)           
    end
end


display('MCI vs NC')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Cntrl vs MCI %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for bnd=2:size(band,2)
    sig_per_freq_MCI =[];
    for i=1:size(band{bnd},2)
        sig_per_freq_MCI(1,i) = numel(find(MCI_fdr_sig_05(:,band{bnd}(i))==1))/400;
    end
    [val,idx]=max(sig_per_freq_MCI)

    for i=1:size(band{bnd},2)
        MCI_fdr_sig_05(:,band{bnd}(i)) = MCI_fdr_sig_05(:,band{bnd}(i)).*MCI_fdr_sig_05(:,band{bnd}(idx));
    end
end
MCI_fdr_sig_05(find(MCI_fdr_sig_05==0))=NaN;
sig_NC_MCI_exp={};
temp_exp_sig={};
for k=1:2:3
    for sb=1:size(temp_exp{k},3)
        ttmp =[];
        ttmp(:,:) = temp_exp{k}(:,:,sb);
        temp_exp_sig{k}(:,:,sb) = ttmp(:,:).*MCI_fdr_sig_05;
    end
    for bnd=2:size(band,2)
        for i=1:size(Netwroks_17,1)
            temp_net = [];
            temp_net = Netwroks_17(i,:);
            temp_net = temp_net((temp_net ~= -1));
            sig_NC_MCI_exp{k}{bnd}{i}(:,1) = nanmean(nanmean(temp_exp{k}(temp_net,band{bnd},:),2),1);
        end
    end
end

for bnd=2:size(band,2)
    for i=1:size(Netwroks_17,1)
        data=[];
        data(:,1) = sig_NC_MCI_exp{1}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\fEI\Significant Diff Parcel\17 Network Data\NC vs MCI\NC\fEI_Sig_' Network_17_labels{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)
        data=[];
        data(:,1) = sig_NC_MCI_exp{3}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\fEI\Significant Diff Parcel\17 Network Data\NC vs MCI\MCI\fEI_Sig_' Network_17_labels{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)           
    end
end

display('       SCD vs MCI')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% SCD vs MCI %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for bnd=2:size(band,2)
    sig_per_freq_SM =[];
    for i=1:size(band{bnd},2)
        sig_per_freq_SM(1,i) = numel(find(SM_fdr_sig_05(:,band{bnd}(i))==1))/400;
    end
    [val,idx]=max(sig_per_freq_SM)

    for i=1:size(band{bnd},2)
        SM_fdr_sig_05(:,band{bnd}(i)) = SM_fdr_sig_05(:,band{bnd}(i)).*SM_fdr_sig_05(:,band{bnd}(idx));
    end
end
SM_fdr_sig_05(find(SM_fdr_sig_05==0))=NaN;
sig_SCD_MCI_exp={};
temp_exp_sig={};
for k=2:3
    for sb=1:size(temp_exp{k},3)
        ttmp =[];
        ttmp(:,:) = temp_exp{k}(:,:,sb);
        temp_exp_sig{k}(:,:,sb) = ttmp(:,:).*SM_fdr_sig_05;
    end
    for bnd=2:size(band,2)
        for i=1:size(Netwroks_17,1)
            temp_net = [];
            temp_net = Netwroks_17(i,:);
            temp_net = temp_net((temp_net ~= -1));
            sig_SCD_MCI_exp{k}{bnd}{i}(:,1) = nanmean(nanmean(temp_exp{k}(temp_net,band{bnd},:),2),1);
        end
    end
end

for bnd=2:size(band,2)
    for i=1:size(Netwroks_17,1)
        data=[];
        data(:,1) = sig_SCD_MCI_exp{2}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\fEI\Significant Diff Parcel\17 Network Data\SCD vs MCI\SCD\fEI_Sig_' Network_17_labels{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)
        data=[];
        data(:,1) = sig_SCD_MCI_exp{3}{bnd}{i};
            fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Classifier Data\fEI\Significant Diff Parcel\17 Network Data\SCD vs MCI\MCI\fEI_Sig_' Network_17_labels{i} '_' bnd_name{bnd}  '.csv'];
%         csvwrite(fname,data)           
    end
end

