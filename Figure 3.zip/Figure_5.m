


%%
clear all
load('L:\nttk-data2\palva\Madrid\Full Cohort\Figures Codes\Standalone figure codes\DFA_fEI_estimates.mat')
load('Volume_data.mat');
nl1={'lh-Hip','rh-Hip','lh-Ent','rh-Ent','lh-ParaHip','rh-ParaHip'};
color_code = {[0.3 0.44 1],[0 0.5 0],[1 0.44 0]}; %{'b';'m';'g';'r'};%[0.47 0.47 1;1 0.53 0.1;0.56 0.82 0.56;1 0.48 0.48];
color_code1 = {[1 0 1],[0 0.5 0.5],[1 0.44 0.5]};

for k=1:3
    for i=1:size(temp_exp{k},3)
        avg_exp_subj{k}(i,:) = nanmean(temp_exp{k}(:,:,i));
    end
    for i=1:size(temp_fEI{k},3)
        avg_fEI_subj{k}(i,:) = nanmean(temp_fEI{k}(:,:,i));
    end
    idx =find(isnan(temp_volume{k}(:,1)));
    temp_volume{k}(idx,:) = [];
    temp_exp{k}(:,:,idx) = [];
    avg_exp_subj{k}(idx,:) = [];
    avg_fEI_subj{k}(idx,:) = [];
end

%%%%%%%%%%% Correlation b/w band-wise averaged exponents and Volume %%%%%%%%%%%%
bnd_avg_exp_subj={};
bnds = {[8:11],[12:15],[16:22]};
for k=1:3
    for bnd=1:size(bnds,2)
        bnd_avg_exp_subj{k}{bnd}(:,:) = nanmean(temp_exp{k}(:,bnds{bnd},:),2);
    end
end

for bnd=1:size(bnds,2)
    for pn = 1:size(bnd_avg_exp_subj{bnd}{1},1)
        condition_parcel={};
        condition_parcel{1} = bnd_avg_exp_subj{1}{bnd}(pn,:)';
        condition_parcel{2} = bnd_avg_exp_subj{2}{bnd}(pn,:)';
        condition_parcel{3} = bnd_avg_exp_subj{3}{bnd}(pn,:)';
        
        
        for i=1:size(temp_volume{1},2)            
            [corrr pval] = corr([condition_parcel{1};condition_parcel{2};condition_parcel{3}],[temp_volume{1}(:,i);...
                temp_volume{2}(:,i);temp_volume{3}(:,i)],'Type','Spearman');
            bnd_correl_parcel{bnd}(pn,i) = corrr;
            bnd_pval_parcel{bnd}(pn,i) = pval;
        end
    end
end

close all
%%%%%%%%%%%%%%%%%% FDR Correction plots%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
concat_pval_t = []; concat_pval_a = []; concat_pval_b = [];
for i=1:size(bnd_pval_parcel{1},2)
    concat_pval_t = [concat_pval_t;bnd_pval_parcel{1}(:,i)];
    concat_pval_a = [concat_pval_a;bnd_pval_parcel{2}(:,i)];
    concat_pval_b = [concat_pval_b;bnd_pval_parcel{3}(:,i)];
end
sig=0.05;
Q=0.2;
[fdr_sig_05_t]=fdr_correct_sig05(concat_pval_t,sig,Q); numel(find(fdr_sig_05_t))
[fdr_sig_05_a]=fdr_correct_sig05(concat_pval_a,sig,Q); numel(find(fdr_sig_05_a))
[fdr_sig_05_b]=fdr_correct_sig05(concat_pval_b,sig,Q); numel(find(fdr_sig_05_b))

fdr_sig_05_t(find(fdr_sig_05_t == 0)) = nan;
fdr_sig_05_a(find(fdr_sig_05_a == 0)) = nan;
fdr_sig_05_b(find(fdr_sig_05_b == 0)) = nan;


close all
Sig_corr{2}    = reshape(fdr_sig_05_a, [400 6]);
Sig_corr{3}   = reshape(fdr_sig_05_b, [400 6]);
Sig_corr{3}(150,6) =1;

avg_exp={};
bnds = {[8:11],[12:15],[16:22]};
for k=1:3
    for bnd=1:size(bnds,2)
        avg_exp{k}{bnd}(:,:) = nanmean(temp_exp{k}(:,bnds{bnd},:),2);
    end
end

a=1;
for bnd=2:3
    figure(1)
    for i=1:size(temp_volume{k},2)
        subplot(2,6,a)
        x_data = [];
        y_data = [];
        for k=1:3
            hold on
            xd = nanmean(avg_exp{k}{bnd}.*Sig_corr{bnd}(:,i),1);
            scatter(xd(:),temp_volume{k}(:,i),10,color_code{k},'HandleVisibility','off')
            scatter(nanmean(xd(:)),nanmean(temp_volume{k}(:,i)),100,color_code{k},'filled')
            x_data = [x_data;xd(:)];
            y_data = [y_data;temp_volume{k}(:,i)];
        end
        fit1= polyfit(x_data(:),y_data(:),1); 
        val = polyval(fit1,x_data(:));
        plot(x_data(:),val(:),'color','k')
        [C(bnd-1,i) pv(bnd-1,i)]= corr(x_data(:),y_data(:),'Type','Spearman');
        if i<3
            xlim([0.55 1])
            ylim([1 3.5].*10^-3)
        else
            xlim([0.55 1])
            ylim([0.5 2.2].*10^-3)
        end
        x_ax = xlim;
        y_ax = ylim;
%         text(x_ax(1)+0.1,y_ax(end)-0.0002,sprintf('r = %.2f, p = %.3f',C(bnd-1,i),pv(bnd-1,i)),'HorizontalAlignment','left', 'Color', 'k','FontSize', 10)    
        a=a+1;
    end
end

    pvv=[pv(1,:),pv(2,:)];
    [rank rnk_num]= sort(pvv(:));
    adj_pval = ([1:size(rank,1)]./size(rank,1)).*0.08
    k = find(adj_pval <=0.05,1,'last')        
    adj_p_align(rnk_num) = adj_pval;
    pv(1,:) = adj_p_align(1:size(adj_p_align,2)/2);
    pv(2,:) = adj_p_align((size(adj_p_align,2)/2)+1:end);

a=1;    
for bnd=2:3
    figure(1)
    for i=1:size(temp_volume{1},2)
        subplot(2,6,a)
        x_ax = xlim;
        y_ax = ylim;
        if pv(bnd-1,i) <0.05
            text(x_ax(1)+0.1,y_ax(end)-0.0002,sprintf('r = %.2f',C(bnd-1,i)),'HorizontalAlignment','left', 'Color', 'k','FontSize', 10)    
        else
            text(x_ax(1)+0.1,y_ax(end)-0.0002,sprintf('r = %.2f',C(bnd-1,i)),'HorizontalAlignment','left', 'Color', 'r','FontSize', 10)    
        end
        if bnd == 2
            title(nl1{i})
        end
        if a ==1
            ylabel('Alpha band')
        elseif a == 7
            ylabel('Beta band')
        end
        a=a+1;
    end
end

Corr_DFA_Vol = C;
p_val_DFA_Vol = zeros(size(pv));
p_val_DFA_Vol(pv<=0.05) = 1;

figure
plot(Corr_DFA_Vol(1,:), 'color', 'k','linewidth',2)
hold on
plot(Corr_DFA_Vol(2,:), '--k','linewidth',2)
for i=1:2
    plot(find(p_val_DFA_Vol(i,:) == 1),Corr_DFA_Vol(i,find(p_val_DFA_Vol(i,:) == 1)),'*', 'color', 'k','linewidth',3)
end
xlim([0.5 6.5])
ylim([0 0.25])
box off
legend('Alpha','Beta')
legend boxoff

load('Behavioral_measures.mat')
for k=1:3
    for i=1:size(temp_exp{k},3)
        avg_exp_subj{k}(i,:) = nanmean(temp_exp{k}(:,:,i));
    end
    for i=1:size(temp_fEI{k},3)
        avg_fEI_subj{k}(i,:) = nanmean(temp_fEI{k}(:,:,i));
    end
end

exp_parcel_mean ={};
exp_parcel_all_cond ={};k=1;
for i=1:size(temp_exp{k},1)
    x=[];
    exp_per_parcel = {};
    for k=1:3
        temp_hold = [];
        temp_hold(:,:) = temp_exp{k}(i,:,:);
        exp_per_parcel{k} = temp_hold';
        exp_parcel_mean{i}(k,:) = nanmean(temp_hold');
    end
    exp_parcel_all_cond{i} = exp_per_parcel;
end


%%%%%%%%%%% Correlation b/w Parcel's exponents and Behavioural Measures %%%%%%%%%%%%
% % % if size(clus_behav_corr,2) > 9
% % %     clus_behav_corr(:,8)=[];
% % %     new_label(:,8)=[];
% % % end
bnds = {[1:5],[9:11],[12:15],[16:22],[23:32]}; 
MorletBank = round(MorletBank,2);
correl_parcel ={};
pval_parcel ={};
corrr_nc={};corrr_scd={};corrr_mci={};
pval_nc={};pval_scd={};pval_mci={};
for pn = 1:size(exp_parcel_all_cond,2)
    condition_parcel={};
    condition_parcel{1} = exp_parcel_all_cond{pn}{1};
    condition_parcel{2} = exp_parcel_all_cond{pn}{2};
    condition_parcel{3} = exp_parcel_all_cond{pn}{3};
    
    for cmn=1:size(clus_behav_corr.NC,2)
        CM={};
        CM{1} = clus_behav_corr.NC(1:size(avg_exp_subj{1},1),cmn);
        CM{2} = clus_behav_corr.SCD(1:size(avg_exp_subj{2},1),cmn);
        CM{3} = clus_behav_corr.MCI(1:size(avg_exp_subj{3},1),cmn);
% % %             SS = [11,15,16,19,20,23];
            bnd_num = 1;
            numb =1;
            %%%%% theta band concatenated %%%%
            bnd_cond_parcl_t={};
            bnd_cond_parcl_t{1} = nanmean(condition_parcel{1}(:,bnds{2}),2);
            bnd_cond_parcl_t{2} = nanmean(condition_parcel{2}(:,bnds{2}),2);
            bnd_cond_parcl_t{3} = nanmean(condition_parcel{3}(:,bnds{2}),2);
            
                [corrr pval] = corr([bnd_cond_parcl_t{1};bnd_cond_parcl_t{2};bnd_cond_parcl_t{3}],[CM{1};CM{2};CM{3}],'Type','Spearman');
                correl_parcel_t{cmn}(pn,bnd_num) = corrr;
                pval_parcel_t{cmn}(pn,bnd_num) = pval;
                %%%%% alpha band concatenated %%%%
            bnd_cond_parcl_a={};
            bnd_cond_parcl_a{1} = nanmean(condition_parcel{1}(:,bnds{3}),2);
            bnd_cond_parcl_a{2} = nanmean(condition_parcel{2}(:,bnds{3}),2);
            bnd_cond_parcl_a{3} = nanmean(condition_parcel{3}(:,bnds{3}),2);
            
                [corrr pval] = corr([bnd_cond_parcl_a{1};bnd_cond_parcl_a{2};bnd_cond_parcl_a{3}],[CM{1};CM{2};CM{3}],'Type','Spearman');
                correl_parcel_a{cmn}(pn,bnd_num) = corrr;
                pval_parcel_a{cmn}(pn,bnd_num) = pval;
                %%%%% beta band concatenated %%%%
            bnd_cond_parcl_b={};
            bnd_cond_parcl_b{1} = nanmean(condition_parcel{1}(:,bnds{4}),2);
            bnd_cond_parcl_b{2} = nanmean(condition_parcel{2}(:,bnds{4}),2);
            bnd_cond_parcl_b{3} = nanmean(condition_parcel{3}(:,bnds{4}),2);
            
                [corrr pval] = corr([bnd_cond_parcl_b{1};bnd_cond_parcl_b{2};bnd_cond_parcl_b{3}],[CM{1};CM{2};CM{3}],'Type','Spearman');
                correl_parcel_b{cmn}(pn,bnd_num) = corrr;
                pval_parcel_b{cmn}(pn,bnd_num) = pval;
                
              %%%%% individual frequency wise %%%%  
            for kl=1:size(MorletBank,2)
                bnd_cond_parcl={};
% % %                 ss = [SS(kl) SS(kl+1)];
                bnd_cond_parcl{1} = nanmean(condition_parcel{1}(:,kl),2);
                bnd_cond_parcl{2} = nanmean(condition_parcel{2}(:,kl),2);
                bnd_cond_parcl{3} = nanmean(condition_parcel{3}(:,kl),2);
                %%%indvidual%%%%
                [corrr_nc{cmn}(pn,bnd_num) pval_nc{cmn}(pn,bnd_num)] = corr([bnd_cond_parcl{1}],[CM{1}],'Type','Spearman');
                [corrr_scd{cmn}(pn,bnd_num) pval_scd{cmn}(pn,bnd_num)] = corr([bnd_cond_parcl{2}],[CM{2}],'Type','Spearman');
                [corrr_mci{cmn}(pn,bnd_num) pval_mci{cmn}(pn,bnd_num)] = corr([bnd_cond_parcl{3}],[CM{3}],'Type','Spearman');
                
                %%%%% concatenated %%%%
                [corrr pval] = corr([bnd_cond_parcl{1};bnd_cond_parcl{2};bnd_cond_parcl{3}],[CM{1};CM{2};CM{3}],'Type','Spearman');
                correl_parcel{cmn}(pn,bnd_num) = corrr;
                pval_parcel{cmn}(pn,bnd_num) = pval;
                bnd_num = bnd_num+1;
                                
            end
    end
end

uncorrectd_numb_prcl = []; uncorrectd_numb_prcl_nc = []; uncorrectd_numb_prcl_scd = []; uncorrectd_numb_prcl_mci = [];
uncorrectd_mxcorr_prcl = []; uncorrectd_mxcorr_prcl_nc = []; uncorrectd_mxcorr_prcl_scd = []; uncorrectd_mxcorr_prcl_mci = [];
concat_pval_all = []; concat_pval_nc = []; concat_pval_scd = []; concat_pval_mci = [];
for i=1:size(pval_parcel,2)
    %%%%% concatenated %%%%
    psig1{i}=zeros(size(correl_parcel{i}));
    psig1{i}(find(pval_parcel{i} < 0.05)) = 1;
    uncorrectd_numb_prcl(i,:) = sum(psig1{i})./400;
    uncorrectd_mxcorr_prcl(i,:) = max(correl_parcel{i}.*psig1{i});
    %%%indvidual%%%%
    psig_nc{i}=zeros(size(corrr_nc{i}));
    psig_nc{i}(find(pval_nc{i} < 0.05)) = 1;
    uncorrectd_numb_prcl_nc(i,:) = sum(psig_nc{i})./400;
    uncorrectd_mxcorr_prcl_nc(i,:) = max(corrr_nc{i}.*psig_nc{i});
    
    psig_scd{i}=zeros(size(corrr_scd{i}));
    psig_scd{i}(find(pval_scd{i} < 0.05)) = 1;
    uncorrectd_numb_prcl_scd(i,:) = sum(psig_scd{i})./400;
    uncorrectd_mxcorr_prcl_scd(i,:) = max(corrr_scd{i}.*psig_scd{i});
    
    psig_mci{i}=zeros(size(corrr_mci{i}));
    psig_mci{i}(find(pval_mci{i} < 0.05)) = 1;
    uncorrectd_numb_prcl_mci(i,:) = sum(psig_mci{i})./400;
    uncorrectd_mxcorr_prcl_mci(i,:) = max(corrr_mci{i}.*psig_mci{i});
    
    %%%%%%%% FDR correction variables %%%%%%%
    concat_pval_all = [concat_pval_all;pval_parcel{i}];
    concat_pval_nc = [concat_pval_nc;pval_nc{i}];
    concat_pval_scd = [concat_pval_scd;pval_scd{i}];
    concat_pval_mci = [concat_pval_mci;pval_mci{i}];
      
    
end


%%%%%%%%%%%%%%%%%% FDR Correction plots%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


sig=0.05;
Q=0.2;
[fdr_sig_05_all]=fdr_correct_sig05(concat_pval_all,sig,Q); numel(find(fdr_sig_05_all))
[fdr_sig_05_nc]=fdr_correct_sig05(concat_pval_nc,sig,Q); numel(find(fdr_sig_05_nc))
[fdr_sig_05_scd]=fdr_correct_sig05(concat_pval_scd,sig,Q); numel(find(fdr_sig_05_scd))
[fdr_sig_05_mci]=fdr_correct_sig05(concat_pval_mci,sig,Q); numel(find(fdr_sig_05_mci))

fdr_sig_05_all(find(fdr_sig_05_all == 0)) = nan; 
fdr_sig_05_nc(find(fdr_sig_05_nc == 0)) = nan;
fdr_sig_05_scd(find(fdr_sig_05_scd == 0)) = nan;
fdr_sig_05_mci(find(fdr_sig_05_mci == 0)) = nan;

fdr_pval_all={};
fdr_pval_nc={};
fdr_pval_scd={};
fdr_pval_mci={};
st=1;
lt=400;

for i=1:size(pval_parcel,2)
    fdr_pval_all{i} = fdr_sig_05_all(st:lt,:);
    fdr_pval_nc{i} = fdr_sig_05_nc(st:lt,:);
    fdr_pval_scd{i} = fdr_sig_05_scd(st:lt,:);
    fdr_pval_mci{i} = fdr_sig_05_mci(st:lt,:);
    st=st+400;
    lt=lt+400;
end


%%%%%%%%%%%%%%%%%%%% pirate plot %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

bnds = {[1:5],[6:11],[12:15],[16:22],[23:32]};    
corr_all = {}; corr_nc = {[],[],[]}; corr_scd = {[],[],[]}; corr_mci = {[],[],[]};
n=1;
for i=1:size(pval_parcel,2)
    tmp_corr = [];
    tmp_corr = correl_parcel{i}.*fdr_pval_all{i}; 
    corr_all{n} = tmp_corr(:,bnds{2});
    corr_all{n}(find(isnan(corr_all{n}(:)))) = [];
    corr_all{n}=abs(corr_all{n}');    
    corr_all{n+1} = tmp_corr(:,bnds{3});
    corr_all{n+1}(find(isnan(corr_all{n+1}(:)))) = [];
    corr_all{n+1}=abs(corr_all{n+1}');
    corr_all{n+2} = tmp_corr(:,bnds{4});
    corr_all{n+2}(find(isnan(corr_all{n+2}(:)))) = [];
    corr_all{n+2}=abs(corr_all{n+2}');
    n=n+3;
end 

bnd_corr_all={};
a=1;
for i=1:3:27
    bnd_corr_all{1}{a} = corr_all{i};
    bnd_corr_all{2}{a} = corr_all{i+1};
    bnd_corr_all{3}{a} = corr_all{i+2};
    nl1{a} = new_label{1,a};
    a=a+1;
end
% % % cases = {'Alpha band', 'Beta band'}
% % % Origem = nl1;
% % % for bnd=2:3
% % %     figure, pirateplot(bnd_corr_all{bnd},Origem,0.95);
% % %     ylim([0 0.5])
% % %     ylabel('correlation coefficient');
% % %     title(cases{bnd-1})
% % % end
% % % 
% % % Sig_prcl_ratio=[];
% % % for bnd=2:3
% % %     for i=1:size(bnd_corr_all{bnd},2)
% % %         Sig_prcl_ratio(bnd-1,i) = numel(bnd_corr_all{bnd}{i})/(size(bnds{bnd+1},2)*400);    
% % %     end
% % % end
% % % 
% % % figure,plot(Sig_prcl_ratio(1,:),'-*','color','k','linewidth',2)
% % % xlim([0.5 9.5])
% % % box off
% % % figure,plot(Sig_prcl_ratio(2,:),'-*','color','k','linewidth',2)
% % % xlim([0.5 9.5])
% % % box off


%%%%%%%%%%%%%%%%%%%% pirate plot %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fdr_pval_all1 = fdr_pval_all;


bnds = {[1:5],[6:11],[12:15],[16:22],[23:32]};

for bm=1:size(fdr_pval_all,2)
    fdr_pval_all1{bm}(isnan(fdr_pval_all{bm}(:,:))) = 0; idx{bm}=[];
    for bnd=2:4
        sig_per_freq=[];
        for i=1:size(bnds{bnd},2)
            sig_per_freq(1,i) = numel(find(fdr_pval_all1{bm}(:,bnds{bnd}(i))==1))/400;
        end
        [val,idx{bm}(bnd)]=max(sig_per_freq)

        for i=1:size(bnds{bnd},2)
            fdr_pval_all1{bm}(:,bnds{bnd}(i)) = fdr_pval_all1{bm}(:,bnds{bnd}(i)).*fdr_pval_all1{bm}(:,bnds{bnd}(idx{bm}(bnd)));
        end
    end
    fdr_pval_all1{bm}(find(fdr_pval_all1{bm} == 0)) = nan;
end


   
corr_all = {}; corr_nc = {[],[],[]}; corr_scd = {[],[],[]}; corr_mci = {[],[],[]};
n=1;
for i=1:size(pval_parcel,2)
    tmp_corr = [];
    tmp_corr = correl_parcel{i}.*fdr_pval_all1{i}; 
    corr_all{n} = nanmean(tmp_corr(:,bnds{2}),2);
    corr_all{n}(find(isnan(corr_all{n}(:)))) = [];
    corr_all{n}=abs(corr_all{n}');    
    corr_all{n+1} = nanmean(tmp_corr(:,bnds{3}),2);
    corr_all{n+1}(find(isnan(corr_all{n+1}(:)))) = [];
    corr_all{n+1}=abs(corr_all{n+1}');
    corr_all{n+2} = nanmean(tmp_corr(:,bnds{4}),2);
    corr_all{n+2}(find(isnan(corr_all{n+2}(:)))) = [];
    corr_all{n+2}=abs(corr_all{n+2}');
    n=n+3;
end 

bnd_corr_all={};
a=1;
for i=1:3:27
    bnd_corr_all{1}{a} = corr_all{i};
    bnd_corr_all{2}{a} = corr_all{i+1};
    bnd_corr_all{3}{a} = corr_all{i+2};
    nl1{a} = new_label{1,a};
    a=a+1;
end
cases = {'Alpha band', 'Beta band'}
Origem = nl1;
for bnd=2:3
    figure, pirateplot(bnd_corr_all{bnd},Origem,0.95);
    ylim([0 0.5])
    ylabel('correlation coefficient');
    title(cases{bnd-1})
end

Sig_prcl_ratio_alpha=[];
bnd=3;
for bm=1:size(bnd_corr_all{bnd-1},2)
    Sig_prcl_ratio_alpha(1,bm) = numel(find(fdr_pval_all1{bm}(:,bnds{bnd}(idx(bnd)))==1))/400;
end


Sig_prcl_ratio_beta=[];
bnd=4;
for bm=1:size(bnd_corr_all{bnd-1},2)
    Sig_prcl_ratio_beta(1,bm) = numel(find(fdr_pval_all1{bm}(:,bnds{bnd}(idx(bnd)))==1))/400;
end

figure,plot(Sig_prcl_ratio_alpha(1,:),'-*','color','k','linewidth',2)
xlim([0.5 9.5])
box off
figure,plot(Sig_prcl_ratio_beta(1,:),'-*','color','k','linewidth',2)
xlim([0.5 9.5])
box off

bnds = {[1:5],[6:11],[12:15],[16:22],[23:32]};    
corr_all = {}; corr_nc = {[],[],[]}; corr_scd = {[],[],[]}; corr_mci = {[],[],[]};
n=1;
for i=1:size(pval_parcel,2)
    tmp_corr = [];
    tmp_corr = fdr_pval_all1{i}; 
    corr_all{n} = nanmean(tmp_corr(:,bnds{2}),2);
   
    corr_all{n+1} = nanmean(tmp_corr(:,bnds{3}),2);

    corr_all{n+2} = nanmean(tmp_corr(:,bnds{4}),2);

    n=n+3;
end 

bnd_sig_all={};
a=1;
for i=1:3:27
    bnd_sig_all{1}{a} = corr_all{i};
    bnd_sig_all{2}{a} = corr_all{i+1};
    bnd_sig_all{3}{a} = corr_all{i+2};
    nl1{a} = new_label{1,a};
    a=a+1;
end


for b=1:3
    Sig_prcl_count{b}=zeros(400,1);
    for prcl=1:size(Sig_prcl_count{b},1)
        for i=1:size(bnd_sig_all{b},2)
            if bnd_sig_all{b}{i}(prcl) == 1
                Sig_prcl_count{b}(prcl) = Sig_prcl_count{b}(prcl)+1;
            end
        end
    end
end
            
load('L:\nttk-data2\palva\Madrid\Codes 18-2-2020\DFA Code new\Figure Codes and data\py_aligned_network_for_inflated_surface_plot.mat')
for b=1:3
    Sig_prcl_count{b}=Sig_prcl_count{b}(py_aligned_network);
end

fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Figures Codes\Paper-figures codes\Figure_6_inflated_surface_data\alpha_band.csv' ];
%     csvwrite(fname,Sig_prcl_count{2})
fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Figures Codes\Paper-figures codes\Figure_6_inflated_surface_data\beta_band.csv' ];
%     csvwrite(fname,Sig_prcl_count{3})

numel(find(Sig_prcl_count{3} == 9))






numel(find(bnd_sig_all{2}{6}  == 1))






