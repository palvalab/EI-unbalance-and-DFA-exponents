close all
clear all
clc


load('Figure_3_data.mat')

c = gray(10);
figure
subplot(211)
lower_cuttoff = min(find(freqs >= 2));
color_code = {[0.3 0.44 1],[0 0.5 0],[1 0.44 0]};
color_code1 = {[1 0 1],[0 0.5 0.5],[1 0.44 0.5]};

for k=1:3    
    for j=1:size(avg_exp_subj{k},1)/2
        if k==1
            semilogx(freqs(lower_cuttoff:end),avg_exp_subj{k}(j,lower_cuttoff:end),'color',[0.73 0.83 0.96],'HandleVisibility','off')
            hold on
        elseif k==2
            semilogx(freqs(lower_cuttoff:end),avg_exp_subj{k}(j,lower_cuttoff:end),'color',[0.76 0.87 0.78],'HandleVisibility','off')
        elseif k==3
            semilogx(freqs(lower_cuttoff:end),avg_exp_subj{k}(j,lower_cuttoff:end),'color',[243 205 158]./255,'HandleVisibility','off')
                    
        end
        
        alpha(1)
    end    
end

for k=1:3    
    for j=floor(size(avg_exp_subj{k},1)/2)+2:size(avg_exp_subj{k},1)-8
        if k==1
            semilogx(freqs(lower_cuttoff:end),avg_exp_subj{k}(j,lower_cuttoff:end),'color',[0.73 0.83 0.96],'HandleVisibility','off')
            hold on
        elseif k==2
            semilogx(freqs(lower_cuttoff:end),avg_exp_subj{k}(j,lower_cuttoff:end),'color',[0.76 0.87 0.78],'HandleVisibility','off')
        elseif k==3
            semilogx(freqs(lower_cuttoff:end),avg_exp_subj{k}(j,lower_cuttoff:end),'color',[243 205 158]./255,'HandleVisibility','off')
                    
        end
        
        alpha(1)
    end    
end


for k=1:3    
    for j=size(avg_exp_subj{k},1)-8:size(avg_exp_subj{k},1)
        if k==1
            semilogx(freqs(lower_cuttoff:end),avg_exp_subj{k}(j,lower_cuttoff:end),'color',[0.73 0.83 0.96],'HandleVisibility','off')
            hold on
        elseif k==2
            semilogx(freqs(lower_cuttoff:end),avg_exp_subj{k}(j,lower_cuttoff:end),'color',[0.76 0.87 0.78],'HandleVisibility','off')
        elseif k==3
            semilogx(freqs(lower_cuttoff:end),avg_exp_subj{k}(j,lower_cuttoff:end),'color',[243 205 158]./255,'HandleVisibility','off')
                    
        end
        
        alpha(1)
    end    
end

for k=1:3
    if k==1
        semilogx(freqs(lower_cuttoff:end),nanmean(avg_exp_subj{k}(:,lower_cuttoff:end)),'color',color_code{1},'linewidth',2)
    elseif k==2
        semilogx(freqs(lower_cuttoff:end),nanmean(avg_exp_subj{k}(:,lower_cuttoff:end)),'color',color_code{2},'linewidth',2)
    elseif k==3
        semilogx(freqs(lower_cuttoff:end),nanmean(avg_exp_subj{k}(:,lower_cuttoff:end)),'color',color_code{3},'linewidth',2)
    end
end

xlim([2 90]);
xticks([2 5 10 20 30 50 90]);
xticklabels([2 5 10 20 30 50 90]) 
h = gca; % Get axis to modify
h.XAxis.MinorTick = 'on'; % Must turn on minor ticks if they are off
h.XAxis.MinorTickValues = [4 6 7 8 9 40 60 70 80];
ylim([-2 12])
yticks([-2 0 4 8 12]);

legend boxoff
box off
ylabel('Normalized PSD')
legend('NC','SCD','MCI')

for k=2:3
    for j=1:size(avg_exp_subj{k},1)
        diff_avg_exp_subj{k}(j,:) = avg_exp_subj{k}(j,:) - nanmean(avg_exp_subj{1},1);
    end
end
for k=3:3
    for j=1:size(avg_exp_subj{k},1)
        diff_avg_exp_subj{1}(j,:) = avg_exp_subj{k}(j,:) - nanmean(avg_exp_subj{2},1);
    end
end
subplot(212)
for k=1:3    
    for j=1:size(avg_exp_subj{k},1)
        if k==1
            semilogx(freqs(lower_cuttoff:end),diff_avg_exp_subj{k}(j,lower_cuttoff:end),'color',[255 180 255]./255,'HandleVisibility','off')
            hold on
        elseif k==2
            semilogx(freqs(lower_cuttoff:end),diff_avg_exp_subj{k}(j,lower_cuttoff:end),'color',[0 206 198]./255,'HandleVisibility','off')            
        elseif k==3
            semilogx(freqs(lower_cuttoff:end),diff_avg_exp_subj{k}(j,lower_cuttoff:end),'color',[255 193 180]./255,'HandleVisibility','off')
        end
        alpha(1)
    end    
end
for k=1:3
    if k==1
        semilogx(freqs(lower_cuttoff:end),nanmean(diff_avg_exp_subj{k}(:,lower_cuttoff:end)),'color',color_code1{1},'linewidth',2)
    elseif k==2
        semilogx(freqs(lower_cuttoff:end),nanmean(diff_avg_exp_subj{k}(:,lower_cuttoff:end)),'color',color_code1{2},'linewidth',2)
    elseif k==3
        semilogx(freqs(lower_cuttoff:end),nanmean(diff_avg_exp_subj{k}(:,lower_cuttoff:end)),'color',color_code1{3},'linewidth',2)
    end
end
ylabel('PSD differences')
xlabel('Frequency (Hz)')
legend('MCI-SCD','SCD-NC','MCI-NC')
xlim([2 90]);
xticks([2 5 10 20 30 50 90]);
xticklabels([2 5 10 20 30 50 90]) 
h = gca; % Get axis to modify
h.XAxis.MinorTick = 'on'; % Must turn on minor ticks if they are off
h.XAxis.MinorTickValues = [3 4 6 7 8 9 40 60 70 80];
ylim([-4 8])
yticks([-4:4:8]);
legend boxoff
box off
MorletBank=round(MorletBank,2);

Mor_freqs=[];
for cnt =1:size(MorletBank,2)
    Mor_freqs(cnt) = find(round(freqs(:),2) == round(MorletBank(cnt),1))
end

    grouplabel = [repmat({'cntrl'},size(temp_exp{1},3),1); repmat({'scd'},size(temp_exp{2},3),1) ...
    ; repmat({'mci'},size(temp_exp{3},3),1)];
    fEI_tbl_true={};
    fEI_sub_true_distribution =[];
    fEI_sub_ovrall_sig_05 = zeros(1,size(avg_exp_subj{1},2));
    fEI_sub_p_true = [];
    fEI__per_sub = [];
    for k=1:3
        temp_hold = [];
        temp_hold = avg_exp_subj{k}(:,Mor_freqs);
        fEI__per_sub = [fEI__per_sub;  temp_hold];
    end

    for m=1:size(Mor_freqs,2)
        
        [fEI_sub_p_true(m), fEI_tbl_true{m}] = kruskalwallis(fEI__per_sub(:,m),grouplabel,'off');
        fEI_sub_true_distribution(m) = fEI_tbl_true{m}{2,5};                   
    end
    
    [rank rnk_num]= sort(fEI_sub_p_true);
    adj_pval = ([1:size(rank,2)]./size(rank,2)).*0.2
    k = find(adj_pval <=0.05,1,'last')
    rank(k+1:end) = 1;
    
    ytick = 11;
    xloc = find(fEI_sub_p_true <= 0.05);
    
    
    subplot(211)
    adj_p_align(rnk_num) = rank;
    xloc3 = find(adj_p_align <= 0.05);

    adj_pval(rnk_num) = adj_pval;
    adj_p_align(xloc3) = adj_pval(xloc3);
    
    semilogx(MorletBank(xloc3),ytick(end)-0.002,'rd', 'MarkerFaceColor', 'r','MarkerSize',6,'HandleVisibility','off');
    
    st = find(adj_p_align <=0.05,1,'first')    
    lst = find(adj_p_align <=0.05,1,'last')
    
    subplot(212)
    grouplabel12 = [ repmat({'cntrl'},size(temp_exp{1},3),1) ...
        ; repmat({'scd'},size(temp_exp{2},3),1)];
    
    sub_true_distribution_dif12=zeros(size(MorletBank)); sub_p_true_dif12=ones(size(MorletBank)); tbl_true_dif12={};
    
    exp_per_sub = [];
    for k=1:2
        temp_hold = [];
        temp_hold = avg_exp_subj{k}(:,Mor_freqs(xloc3));
        exp_per_sub = [exp_per_sub;  temp_hold];
    end
    for m=1:size(exp_per_sub,2)
        [sub_p_true_dif12(xloc3(m)), tbl_true_dif12{m}] = kruskalwallis(exp_per_sub(:,m),grouplabel12,'off');
        sub_true_distribution_dif12(xloc3(m)) = tbl_true_dif12{m}{2,5};                   
    end
    
     
    ypos = nanmean(diff_avg_exp_subj{k}(:,Mor_freqs));

    xloc = find(sub_p_true_dif12 <= 0.05);
    yloc = ypos(xloc);
    semilogx(MorletBank(xloc),yloc,'d', 'MarkerEdgeColor', color_code1{2}, 'MarkerFaceColor', color_code1{2},'MarkerSize',6,'HandleVisibility','off');

    

    grouplabel13 = [ repmat({'cntrl'},size(temp_exp{1},3),1) ...
        ; repmat({'mci'},size(temp_exp{3},3),1)];
    
    sub_true_distribution_dif13=zeros(size(MorletBank)); sub_p_true_dif13=ones(size(MorletBank)); tbl_true_dif13={};
    
    exp_per_sub = [];
    for k=1:2:3
        temp_hold = [];
        temp_hold = avg_exp_subj{k}(:,Mor_freqs(xloc3));
        exp_per_sub = [exp_per_sub;  temp_hold];
    end
    for m=1:size(exp_per_sub,2)
        [sub_p_true_dif13(xloc3(m)), tbl_true_dif13{m}] = kruskalwallis(exp_per_sub(:,m),grouplabel13,'off');
        sub_true_distribution_dif13(xloc3(m)) = tbl_true_dif13{m}{2,5};                   
    end

  
    ypos = nanmean(diff_avg_exp_subj{3}(:,Mor_freqs));


    xloc = find(sub_p_true_dif13 <= 0.05);
    yloc = ypos(xloc);
    semilogx(MorletBank(xloc),yloc,'d', 'MarkerEdgeColor', color_code1{3}, 'MarkerFaceColor', color_code1{3},'MarkerSize',8,'HandleVisibility','off');

    
    grouplabe23 = [ repmat({'scd'},size(temp_exp{2},3),1) ...
        ; repmat({'mci'},size(temp_exp{3},3),1)];

    sub_true_distribution_dif23=zeros(size(MorletBank)); sub_p_true_dif23=ones(size(MorletBank)); tbl_true_dif23={};
    
    exp_per_sub = [];
    for k=2:3
        temp_hold = [];
        temp_hold = avg_exp_subj{k}(:,Mor_freqs(xloc3));
        exp_per_sub = [exp_per_sub;  temp_hold];
    end
    for m=1:size(exp_per_sub,2)
        [sub_p_true_dif23(xloc3(m)), tbl_true_dif23{m}] = kruskalwallis(exp_per_sub(:,m),grouplabe23,'off');
        sub_true_distribution_dif23(xloc3(m)) = tbl_true_dif23{m}{2,5};                   
    end
    
    ypos = nanmean(diff_avg_exp_subj{1}(:,Mor_freqs));

    xloc = find(sub_p_true_dif23 <= 0.05);
    yloc = ypos(xloc);
    semilogx(MorletBank(xloc),yloc,'d', 'MarkerEdgeColor', color_code1{1}, 'MarkerFaceColor', color_code1{1},'MarkerSize',4,'HandleVisibility','off');


avg_band = 1;
if avg_band == 1
    delta = find(freqs <= 4);
    theta = find(freqs > 4 & freqs <= 8);
    alpha = find(freqs > 8 & freqs <= 12);
    beta = find(freqs > 12 & freqs <= 30);
    gamma = find(freqs > 30 & freqs <= 90);

    for k=1:3
        avg_bnds_psd{k} = [nanmean(avg_exp_subj{k}(:,delta),2),nanmean(avg_exp_subj{k}(:,theta),2),nanmean(avg_exp_subj{k}(:,alpha),2)...
            nanmean(avg_exp_subj{k}(:,beta),2),nanmean(avg_exp_subj{k}(:,gamma),2)];
    %     figure,histogram(avg_bnds_psd{k}(:,3))
    end
else
    avg_bnds_psd = avg_exp_subj;
end

grouplabel = [repmat({'cntrl'},size(avg_exp_subj{1},1),1); repmat({'scd'},size(avg_exp_subj{2},1),1) ...
    ; repmat({'mci'},size(avg_exp_subj{3},1),1)];
tbl_true={};
sub_true_distribution =[];
sub_srce_sig_05 = zeros(1,size(avg_bnds_psd{1},2));
sub_p_true = [];
    exp_per_sub = [];
    for k=1:3
        temp_hold = [];
        temp_hold = avg_bnds_psd{k};
        exp_per_sub = [exp_per_sub;  temp_hold];
    end

    for m=1:size(exp_per_sub,2)
        [p(m),tbl{m},stats] = anova1(exp_per_sub(:,m),grouplabel,'off');
% % %         [H_true(m),P_true(m),CI_true{m},STATS_true{m}] = ttest2(exp_per_sub(1:56,m),exp_per_sub(57:end,m),0.05,'both');

        [sub_p_true(m), tbl_true{m}] = kruskalwallis(exp_per_sub(:,m),grouplabel,'off');
        sub_true_distribution(m) = tbl_true{m}{2,5};                   
    end

    sub_srce_sig_05(find(sub_p_true < 0.05/5))=1;
    a = find(p < 0.05/5)
    All_t_b_bnd_data = {};    
%     CIFcn = @(x,p)prctile(x,abs([0,100]-(100-p)/2));
    jit = [0.1,0.15,0.2];
    p = 95;
    hold on
    n=1;
    for k=1:3
        t_b_band = avg_bnds_psd{k}(:,2:4);
        All_t_b_bnd_data{n} = t_b_band(:,1)';
        All_t_b_bnd_data{n+3} = t_b_band(:,2)';
        All_t_b_bnd_data{n+6} = t_b_band(:,3)';
        n=n+1;
        
    end

    
    %%%%%%%%%%%%%%%%%%%% pirate plot %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    

    lbl1 = {'NC','SCD','MCI'};
    Origem = [lbl1,lbl1,lbl1];

    Paleta = [color_code{1};color_code{2};color_code{3}];
    Paleta = [Paleta;Paleta;Paleta];
    figure, pirateplot(All_t_b_bnd_data,Origem,0.95,Paleta);
    xticks([3 9 15])
    xticklabels(Origem)
    ylim([-1 6])
    ylabel('Normalized PSD','FontSize',10);
    xlabel('Frequency Bands','FontSize',10);
    xticklabels({'Theta','Alpha','Beta'})
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
for i=1:2
    for j=i+1:3
        exp_per_sub = [];
        exp_per_sub = [avg_bnds_psd{i};avg_bnds_psd{j}];

        for m=1:size(exp_per_sub,2)
            [p_true12{i,j}(m),h_true12{i,j}(m),tbl_true12{i,j}{m}] = ranksum(exp_per_sub(1:size(avg_bnds_psd{i},1),m),exp_per_sub(size(avg_bnds_psd{i},1)+1:end,m));
        end
        h_true12{i,j} = double(p_true12{i,j}< 0.05/15);
        p_true_corr{i,j} = p_true12{i,j}.*15;
    end
end    
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

