function [rho,p_rho] = quad_fit_all_longitdnl(fEI_ratio,dfa_data,color_code,opt,xlabl,ylabl,sc,x_ax,y_ax,k)

%  fEI_ratio = fE/I values
%
%  dfa_data = DFA exponents
%
%  color_code = color value e.g. [0.3 0.44 1] OR 'b'
%
%  opt = option for plot: 1 --> calculate quadratic fit which includes linear part
%                         2 --> calculate quadratic fit excluding linear part
%  
%  xlabl/ylabl = name of measure at x-axis/y-axis

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%% linear fit
    fit1= polyfit(fEI_ratio(:),dfa_data(:),1); 
    val = polyval(fit1,fEI_ratio(:));
    
    %%%% quad fit which include linear part
    [fit2 S]= polyfit(fEI_ratio(:),dfa_data(:),2);
    val2 = polyval(fit2,fEI_ratio(:));
if opt == 1    
    %%%% plot DFA vs fEI data
    hold on    
% % %     scatter(fEI_ratio(:),dfa_data(:),10,color_code)
    
    %%%% plot linear fit
    plot(fEI_ratio(:),val(:),'color',color_code)

    %%%% plot quadratic fit including linear part
    xplot = linspace(min(fEI_ratio(:))-0.05,max(fEI_ratio(:))+0.05,300); % get fine resolution x-axis
    valplot = polyval(fit2,xplot(:)); % calculate quad fit on new x-axis points
    plot(xplot(:),valplot(:),'r--','linewidth',2)
    
    %%%% calculate Confidence interval for quad fit
    [quadval1,DELTA] = polyconf(fit2,xplot(:),S,'alpha',0.05);
    plot(xplot,quadval1(:)+mean(DELTA),'r--')
    plot(xplot,quadval1(:)-mean(DELTA),'r--')
    
    
    [C pv]= corr(fEI_ratio(:),dfa_data(:),'Type','pearson') % linear correlation value
    
    %%%% to get rho (equivalent of linear correlation from gof)
    quad_model = polyfitn(fEI_ratio(:),dfa_data(:),2); 
    rho = sign(quad_model.AdjustedR2)*sqrt(abs(quad_model.AdjustedR2));
    p_rho = quad_model.p(3); % p value for rho
% % %     x_ax = xlim;
    y_ax = ylim;
% % %     ylim(y_ax);
    xlim(x_ax);
    text(x_ax(1)+0.01,y_ax(end)-0.02,sprintf('r = %.2f, p = %.3f',C,pv),'HorizontalAlignment','left', 'Color', color_code,'FontSize', 10)
    text(x_ax(1)+0.01,y_ax(end)-0.05,sprintf('rho = %.2f, p-rho = %.3f',rho,p_rho),'HorizontalAlignment','left', 'Color', 'r','FontSize', 10)
    
    xlabel(xlabl)
    ylabel(ylabl)
% % %     title('DFA vs fE/I: fE/I calculated using 5 second Window')
    set(gca,'FontSize', 12)
else
    
    hold on
    lin_res = dfa_data(:)-val(:); % exclude linear part in data
    mdl = polyfitn(fEI_ratio(:),lin_res(:),2)
    rho = sign(mdl.AdjustedR2)*sqrt(abs(mdl.AdjustedR2));
    p_rho = mdl.p(3);
    
    if k~=999
        scatter(fEI_ratio(:),lin_res(:),10,color_code)            
        scatter(nanmean(fEI_ratio(:)),nanmean(lin_res(:)),100,color_code,'filled')
    end
    if sc==true
        %%%% caclulate & plot quadratic fit excluding linear part
        xplot = linspace(min(fEI_ratio(:))-0.002,max(fEI_ratio(:))+0.002,300); % get fine resolution x-axis
        [B S]= polyfit(fEI_ratio(:),lin_res(:),2); % calculate quad fit, excluding linear part
        quadval = polyval(B,xplot(:));
        plot(xplot,quadval(:),'r--','linewidth',2)

        %%%% calculate Confidence interval for quad fit
        [quadval1,DELTA] = polyconf(B,xplot(:),S,'alpha',0.05); 
        plot(xplot,quadval(:)+mean(DELTA),'r--')
        plot(xplot,quadval(:)-mean(DELTA),'r--')

        %%%% to get rho (equivalent of linear correlation from gof: goodness of fit) OR simply use Adjusted R2 (predicted variance)        
        mdl = polyfitn(fEI_ratio(:),lin_res(:),2)
        rho = sign(mdl.AdjustedR2)*sqrt(abs(mdl.AdjustedR2));
        p_rho = mdl.p(3);

        %%%% plot of linear fit to verify exclusion of linear part
        fit1= polyfit(fEI_ratio(:),lin_res(:),1); 
        val = polyval(fit1,fEI_ratio(:));
        plot(fEI_ratio(:),val(:),'color',color_code)

        [C pv]= corr(fEI_ratio(:),lin_res(:),'Type','pearson') % linear correlation value

% % %         x_ax = xlim;
        y_ax = ylim;
% % %         ylim(y_ax);
        xlim(x_ax);
        text(x_ax(1)+0.01,y_ax(end)-0.02,sprintf('r = %.2f, p = %.3f',C,pv),'HorizontalAlignment','left', 'Color', color_code,'FontSize', 10)
        text(x_ax(1)+0.01,y_ax(end)-0.05,sprintf('rho = %.2f, p-rho = %.3f',rho,p_rho),'HorizontalAlignment','left', 'Color', 'r','FontSize', 10)


        xlabel(xlabl)
        ylabel(sprintf('Partial %s',ylabl))

    % % %     title('DFA vs fE/I: fE/I calculated using 5 second Window')
%         set(gca,'FontSize', 12)
    
    end
end
