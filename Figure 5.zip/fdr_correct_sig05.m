function [fdr_sig_05]=fdr_correct_sig05(pval_or,sig,Q)

pval=pval_or(:);

[rank rnk_num]= sort(pval);
adj_pval = ([1:size(rank,1)]./size(rank,1)).*Q;
k = find(adj_pval <=0.05,1,'last')
rank(k+1:end) = 1;
FDR_val(rnk_num) = rank;
fdr_adj_pval    = reshape(FDR_val, size(pval_or));
fdr_sig_05 = zeros(size(pval_or));
fdr_sig_05(find(fdr_adj_pval <= 0.05))=1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
corrected = numel(find(FDR_val <= 0.05));