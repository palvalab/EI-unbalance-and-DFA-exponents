close all
clear all
clc


load('L:\nttk-data2\palva\Madrid\Full Cohort\Figures Codes\Standalone figure codes\Longitudinal_data_DFA_fEI.mat')
for k=1:2
    for grp = 1:2
        for i=1:size(temp_exp{k}{grp},3)
            avg_exp_subj{k}{grp}(i,:) = nanmean(temp_exp{k}{grp}(:,:,i));
        end
    end
end


figure%('units','normalized','outerposition',[0 0 1 1])
color_code = {[217 128 16]/255,[255 24 44]/255,[217 128 16]/255,[255 24 44]/255}; %{'b';'m';'g';'r'};%[0.47 0.47 1;1 0.53 0.1;0.56 0.82 0.56;1 0.48 0.48];
CIFcn = @(x,p)prctile(x,abs([0,100]-(100-p)/2));
p = 95;


semilogx(MorletBank,nanmean(avg_exp_subj{1}{1}),'--','color',color_code{1},'linewidth',2)
hold on
semilogx(MorletBank,nanmean(avg_exp_subj{1}{2}),'--','color',color_code{2},'linewidth',2)

for i=1:2
    hold on
    for j=1:size(avg_exp_subj{1}{i},2)
        surgt_means = [];
        for t=1:10000
            surgt_idx = [];
            surgt_data =[];
            surgt_idx = randi(size(avg_exp_subj{1}{i},1),size(avg_exp_subj{1}{i},1),1);
            surgt_data = avg_exp_subj{1}{i}(surgt_idx,j);
            surgt_means(t) = mean(surgt_data);
        end
        CI = CIFcn(surgt_means,p);
        Conf_interval{i}(1,j) = CI(1);
        Conf_interval{i}(2,j) = CI(2);
    end
    curve1 = Conf_interval{i}(1,:);
    curve2 = Conf_interval{i}(2,:);
    t = MorletBank;
    time = [t, fliplr(t)];
    inBetween = [curve1, fliplr(curve2)];
    pl=patch(time, inBetween,color_code{i},'edgecolor','none');
    alpha(0.15)
    set(get(get(pl,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');   
end
semilogx(MorletBank,nanmean(avg_exp_subj{1}{1}),'--','color',color_code{1},'linewidth',2,'HandleVisibility','off')
hold on
semilogx(MorletBank,nanmean(avg_exp_subj{1}{2}),'--','color',color_code{2},'linewidth',2,'HandleVisibility','off')



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


semilogx(MorletBank,nanmean(avg_exp_subj{2}{1}),'color',color_code{3},'linewidth',2)
hold on
semilogx(MorletBank,nanmean(avg_exp_subj{2}{2}),'color',color_code{4},'linewidth',2)

for i=1:2
    hold on
    for j=1:size(avg_exp_subj{2}{i},2)
        surgt_means = [];
        for t=1:10000
            surgt_idx = [];
            surgt_data =[];
            surgt_idx = randi(size(avg_exp_subj{2}{i},1),size(avg_exp_subj{2}{i},1),1);
            surgt_data = avg_exp_subj{2}{i}(surgt_idx,j);
            surgt_means(t) = mean(surgt_data);
        end
        CI = CIFcn(surgt_means,p);
        Conf_interval{i}(1,j) = CI(1);
        Conf_interval{i}(2,j) = CI(2);
    end
    curve1 = Conf_interval{i}(1,:);
    curve2 = Conf_interval{i}(2,:);
    t = MorletBank;
    time = [t, fliplr(t)];
    inBetween = [curve1, fliplr(curve2)];
    pl=patch(time, inBetween,color_code{i+2},'edgecolor','none');
    alpha(0.15)
    set(get(get(pl,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');   
end
semilogx(MorletBank,nanmean(avg_exp_subj{2}{1}),'color',color_code{3},'linewidth',2,'HandleVisibility','off')
hold on
semilogx(MorletBank,nanmean(avg_exp_subj{2}{2}),'color',color_code{4},'linewidth',2,'HandleVisibility','off')


grouplabel = [repmat({'1st'},size(avg_exp_subj{1}{1},1),1); repmat({'2nd'},size(avg_exp_subj{1}{2},1),1)];
tbl_true={};
sub_true_distribution =[];
sub_ovrall_sig_05 = zeros(1,size(avg_exp_subj{2}{1},2));
sub_p_true = [];
    exp_per_sub = [];
    for k=1:2
        temp_hold = [];
        temp_hold = avg_exp_subj{1}{k};
        exp_per_sub = [exp_per_sub;  temp_hold];
    end

    for m=1:size(exp_per_sub,2)
        [sub_p_true(m), tbl_true{m}] = kruskalwallis(exp_per_sub(:,m),grouplabel,'off');
        sub_true_distribution(m) = tbl_true{m}{2,5};                   
    end
    %%%%%%%%%%%% FDR correction %%%%%%%%%%%%%%%%%%%%%%%

    [rank rnk_num]= sort(sub_p_true);
    adj_pval = ([1:size(rank,2)]./size(rank,2)).*0.1
    k = find(adj_pval <=0.05,1,'last')
    rank(k+1:end) = 1;
    
    ylim([0.5 0.8])
    ytick = yticks;
    xloc = find(sub_p_true <= 0.05);
    
        
%     plot(MorletBank(xloc),ytick(end)-0.02,'ks', 'MarkerSize',7);
    adj_p_align(rnk_num) = rank;
    xloc = find(adj_p_align <= 0.05);
    semilogx(MorletBank(xloc),ytick(end)-0.01*ones(size(xloc)),'k*','HandleVisibility','off');
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

grouplabel = [repmat({'1st'},size(avg_exp_subj{2}{1},1),1); repmat({'2nd'},size(avg_exp_subj{2}{2},1),1)];
tbl_true={};
sub_true_distribution =[];
sub_ovrall_sig_05 = zeros(1,size(avg_exp_subj{2}{1},2));
sub_p_true = [];
    exp_per_sub = [];
    for k=1:2
        temp_hold = [];
        temp_hold = avg_exp_subj{2}{k};
        exp_per_sub = [exp_per_sub;  temp_hold];
    end

    for m=1:size(exp_per_sub,2)
        [sub_p_true(m), tbl_true{m}] = kruskalwallis(exp_per_sub(:,m),grouplabel,'off');
        sub_true_distribution(m) = tbl_true{m}{2,5};                   
    end
    %%%%%%%%%%%% FDR correction %%%%%%%%%%%%%%%%%%%%%%%

    [rank rnk_num]= sort(sub_p_true);
    adj_pval = ([1:size(rank,2)]./size(rank,2)).*0.1
    k = find(adj_pval <=0.05,1,'last')
    rank(k+1:end) = 1;
    
    ylim([0.5 0.8])
    ytick = yticks;
    xloc = find(sub_p_true <= 0.05);
    
        
%     plot(MorletBank(xloc),ytick(end)-0.02,'ks', 'MarkerSize',7);
    adj_p_align(rnk_num) = rank;
    xloc = find(adj_p_align <= 0.05);
    semilogx(MorletBank(xloc),ytick(end)-0.02*ones(size(xloc)),'k','linewidth',2,'HandleVisibility','off');
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

grouplabel = [repmat({'1st'},size(avg_exp_subj{1}{1},1),1); repmat({'2nd'},size(avg_exp_subj{2}{1},1),1)];
tbl_true={};
sub_true_distribution =[];
sub_ovrall_sig_05 = zeros(1,size(avg_exp_subj{2}{1},2));
sub_p_true = [];
    exp_per_sub = [];
    for k=1:2
        temp_hold = [];
        temp_hold = avg_exp_subj{k}{1};
        exp_per_sub = [exp_per_sub;  temp_hold];
    end

    for m=1:size(exp_per_sub,2)
        [sub_p_true(m), tbl_true{m}] = kruskalwallis(exp_per_sub(:,m),grouplabel,'off');
        sub_true_distribution(m) = tbl_true{m}{2,5};                   
    end
    %%%%%%%%%%%% FDR correction %%%%%%%%%%%%%%%%%%%%%%%

    [rank rnk_num]= sort(sub_p_true);
    adj_pval = ([1:size(rank,2)]./size(rank,2)).*0.1
    k = find(adj_pval <=0.05,1,'last')
    rank(k+1:end) = 1;
    
    ylim([0.5 0.8])
    ytick = yticks;
    xloc = find(sub_p_true <= 0.05);
    
        
%     plot(MorletBank(xloc),ytick(end)-0.02,'ks', 'MarkerSize',7);
    adj_p_align(rnk_num) = rank;
    xloc = find(adj_p_align <= 0.05);
%     semilogx([MorletBank(xloc(1))-0.2,MorletBank(xloc(1))+0.2],[ytick(end)-0.02,ytick(end)-0.02],'--','color',color_code{1},'linewidth',2,'HandleVisibility','off');
    semilogx(MorletBank(xloc(2:end)),ytick(end)-0.02*ones(size(xloc(2:end))),'color',color_code{1},'linewidth',2,'HandleVisibility','off');
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

grouplabel = [repmat({'1st'},size(avg_exp_subj{1}{2},1),1); repmat({'2nd'},size(avg_exp_subj{2}{2},1),1)];
tbl_true={};
sub_true_distribution =[];
sub_ovrall_sig_05 = zeros(1,size(avg_exp_subj{2}{1},2));
sub_p_true = [];
    exp_per_sub = [];
    for k=1:2
        temp_hold = [];
        temp_hold = avg_exp_subj{k}{2};
        exp_per_sub = [exp_per_sub;  temp_hold];
    end

    for m=1:size(exp_per_sub,2)
        [sub_p_true(m), tbl_true{m}] = kruskalwallis(exp_per_sub(:,m),grouplabel,'off');
        sub_true_distribution(m) = tbl_true{m}{2,5};                   
    end
    %%%%%%%%%%%% FDR correction %%%%%%%%%%%%%%%%%%%%%%%

    [rank rnk_num]= sort(sub_p_true);
    adj_pval = ([1:size(rank,2)]./size(rank,2)).*0.1
    k = find(adj_pval <=0.05,1,'last')
    rank(k+1:end) = 1;
    
    ylim([0.5 0.8])
    ytick = yticks;
    xloc = find(sub_p_true <= 0.05);
    
        
%     plot(MorletBank(xloc),ytick(end)-0.02,'ks', 'MarkerSize',7);
    adj_p_align(rnk_num) = rank;
    xloc = find(adj_p_align <= 0.05);
    semilogx(MorletBank(xloc),ytick(end)-0.03*ones(size(xloc)),'color',color_code{2},'linewidth',2,'HandleVisibility','off');
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



h = gca; % Get axis to modify
h.XAxis.MinorTick = 'on'; % Must turn on minor ticks if they are off
h.XAxis.MinorTickValues = [4 6 7 8 9 40 60 70 80];
ylabel('Scaling exponent (\alpha)','interpreter','Tex','FontSize',12)
legend('Pre-sMCI','Pre-pMCI','Post-sMCI','Post-pMCI')
legend boxoff
xlim([2.2 90])
xticks([3 5 10 20 30 50 90]);
xticklabels([3 5 10 20 30 50 90])
box off
xlabel('Frequency (Hz)')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
clc

load('L:\nttk-data2\palva\Madrid\Full Cohort\Figures Codes\Standalone figure codes\Longitudinal_data_DFA_fEI.mat')
for k=1:2
    for grp = 1:2
        for i=1:size(temp_exp{k}{grp},3)
            avg_exp_subj{k}{grp}(i,:) = nanmean(temp_fEI{k}{grp}(:,:,i));
        end
    end
end


figure%('units','normalized','outerposition',[0 0 1 1])
color_code = {[0 153 153]/255,[126 47 142]/255,[0 153 153]/255,[126 47 142]/255}; %{'b';'m';'g';'r'};%[0.47 0.47 1;1 0.53 0.1;0.56 0.82 0.56;1 0.48 0.48];
CIFcn = @(x,p)prctile(x,abs([0,100]-(100-p)/2));
p = 95;


semilogx(MorletBank,nanmean(avg_exp_subj{1}{1}),'--','color',color_code{1},'linewidth',2)
hold on
semilogx(MorletBank,nanmean(avg_exp_subj{1}{2}),'--','color',color_code{2},'linewidth',2)

for i=1:2
    hold on
    for j=1:size(avg_exp_subj{1}{i},2)
        surgt_means = [];
        for t=1:10000
            surgt_idx = [];
            surgt_data =[];
            surgt_idx = randi(size(avg_exp_subj{1}{i},1),size(avg_exp_subj{1}{i},1),1);
            surgt_data = avg_exp_subj{1}{i}(surgt_idx,j);
            surgt_means(t) = mean(surgt_data);
        end
        CI = CIFcn(surgt_means,p);
        Conf_interval{i}(1,j) = CI(1);
        Conf_interval{i}(2,j) = CI(2);
    end
    curve1 = Conf_interval{i}(1,:);
    curve2 = Conf_interval{i}(2,:);
    t = MorletBank;
    time = [t, fliplr(t)];
    inBetween = [curve1, fliplr(curve2)];
    pl=patch(time, inBetween,color_code{i},'edgecolor','none');
    alpha(0.15)
    set(get(get(pl,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');   
end
semilogx(MorletBank,nanmean(avg_exp_subj{1}{1}),'--','color',color_code{1},'linewidth',2,'HandleVisibility','off')
hold on
semilogx(MorletBank,nanmean(avg_exp_subj{1}{2}),'--','color',color_code{2},'linewidth',2,'HandleVisibility','off')



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


semilogx(MorletBank,nanmean(avg_exp_subj{2}{1}),'color',color_code{3},'linewidth',2)
hold on
semilogx(MorletBank,nanmean(avg_exp_subj{2}{2}),'color',color_code{4},'linewidth',2)

for i=1:2
    hold on
    for j=1:size(avg_exp_subj{2}{i},2)
        surgt_means = [];
        for t=1:10000
            surgt_idx = [];
            surgt_data =[];
            surgt_idx = randi(size(avg_exp_subj{2}{i},1),size(avg_exp_subj{2}{i},1),1);
            surgt_data = avg_exp_subj{2}{i}(surgt_idx,j);
            surgt_means(t) = mean(surgt_data);
        end
        CI = CIFcn(surgt_means,p);
        Conf_interval{i}(1,j) = CI(1);
        Conf_interval{i}(2,j) = CI(2);
    end
    curve1 = Conf_interval{i}(1,:);
    curve2 = Conf_interval{i}(2,:);
    t = MorletBank;
    time = [t, fliplr(t)];
    inBetween = [curve1, fliplr(curve2)];
    pl=patch(time, inBetween,color_code{i+2},'edgecolor','none');
    alpha(0.15)
    set(get(get(pl,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');   
end
semilogx(MorletBank,nanmean(avg_exp_subj{2}{1}),'color',color_code{3},'linewidth',2,'HandleVisibility','off')
hold on
semilogx(MorletBank,nanmean(avg_exp_subj{2}{2}),'color',color_code{4},'linewidth',2,'HandleVisibility','off')


grouplabel = [repmat({'1st'},size(avg_exp_subj{1}{1},1),1); repmat({'2nd'},size(avg_exp_subj{1}{2},1),1)];
tbl_true={};
sub_true_distribution =[];
sub_ovrall_sig_05 = zeros(1,size(avg_exp_subj{2}{1},2));
sub_p_true = [];
    exp_per_sub = [];
    for k=1:2
        temp_hold = [];
        temp_hold = avg_exp_subj{1}{k};
        exp_per_sub = [exp_per_sub;  temp_hold];
    end

    for m=1:size(exp_per_sub,2)
        [sub_p_true(m), tbl_true{m}] = kruskalwallis(exp_per_sub(:,m),grouplabel,'off');
        sub_true_distribution(m) = tbl_true{m}{2,5};                   
    end
    %%%%%%%%%%%% FDR correction %%%%%%%%%%%%%%%%%%%%%%%

    [rank rnk_num]= sort(sub_p_true);
    adj_pval = ([1:size(rank,2)]./size(rank,2)).*0.1
    k = find(adj_pval <=0.05,1,'last')
    rank(k+1:end) = 1;
    
    ylim([0.7 1.1])
    ytick = yticks;
    xloc = find(sub_p_true <= 0.05);
    
        
%     plot(MorletBank(xloc),ytick(end)-0.02,'ks', 'MarkerSize',7);
    adj_p_align(rnk_num) = rank;
    xloc = find(adj_p_align <= 0.05);
    semilogx(MorletBank(xloc),ytick(end)-0.01*ones(size(xloc)),'k*','HandleVisibility','off');
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

grouplabel = [repmat({'1st'},size(avg_exp_subj{2}{1},1),1); repmat({'2nd'},size(avg_exp_subj{2}{2},1),1)];
tbl_true={};
sub_true_distribution =[];
sub_ovrall_sig_05 = zeros(1,size(avg_exp_subj{2}{1},2));
sub_p_true = [];
    exp_per_sub = [];
    for k=1:2
        temp_hold = [];
        temp_hold = avg_exp_subj{2}{k};
        exp_per_sub = [exp_per_sub;  temp_hold];
    end

    for m=1:size(exp_per_sub,2)
        [sub_p_true(m), tbl_true{m}] = kruskalwallis(exp_per_sub(:,m),grouplabel,'off');
        sub_true_distribution(m) = tbl_true{m}{2,5};                   
    end
    %%%%%%%%%%%% FDR correction %%%%%%%%%%%%%%%%%%%%%%%

    [rank rnk_num]= sort(sub_p_true);
    adj_pval = ([1:size(rank,2)]./size(rank,2)).*0.1
    k = find(adj_pval <=0.05,1,'last')
    rank(k+1:end) = 1;
    
    ylim([0.7 1.1])
    ytick = yticks;
    xloc = find(sub_p_true <= 0.05);
    
        
%     plot(MorletBank(xloc),ytick(end)-0.02,'ks', 'MarkerSize',7);
    adj_p_align(rnk_num) = rank;
    xloc = find(adj_p_align <= 0.05);
    semilogx(MorletBank(xloc(1:4)),ytick(end)-0.02*ones(size(xloc(1:4))),'k','linewidth',2,'HandleVisibility','off');
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

grouplabel = [repmat({'1st'},size(avg_exp_subj{1}{1},1),1); repmat({'2nd'},size(avg_exp_subj{2}{1},1),1)];
tbl_true={};
sub_true_distribution =[];
sub_ovrall_sig_05 = zeros(1,size(avg_exp_subj{2}{1},2));
sub_p_true = [];
    exp_per_sub = [];
    for k=1:2
        temp_hold = [];
        temp_hold = avg_exp_subj{k}{1};
        exp_per_sub = [exp_per_sub;  temp_hold];
    end

    for m=1:size(exp_per_sub,2)
        [sub_p_true(m), tbl_true{m}] = kruskalwallis(exp_per_sub(:,m),grouplabel,'off');
        sub_true_distribution(m) = tbl_true{m}{2,5};                   
    end
    %%%%%%%%%%%% FDR correction %%%%%%%%%%%%%%%%%%%%%%%

    [rank rnk_num]= sort(sub_p_true);
    adj_pval = ([1:size(rank,2)]./size(rank,2)).*0.1
    k = find(adj_pval <=0.05,1,'last')
    rank(k+1:end) = 1;
    
    ylim([0.7 1.1])
    ytick = yticks;
    xloc = find(sub_p_true <= 0.05);
    
        
%     plot(MorletBank(xloc),ytick(end)-0.02,'ks', 'MarkerSize',7);
    adj_p_align(rnk_num) = rank;
    xloc = find(adj_p_align <= 0.05);
%     semilogx([MorletBank(xloc(1))-0.2,MorletBank(xloc(1))+0.2],[ytick(end)-0.02,ytick(end)-0.02],'--','color',color_code{1},'linewidth',2,'HandleVisibility','off');
    semilogx(MorletBank(xloc(2:end)),ytick(end)-0.02*ones(size(xloc(2:end))),'color',color_code{1},'linewidth',2,'HandleVisibility','off');
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

grouplabel = [repmat({'1st'},size(avg_exp_subj{1}{2},1),1); repmat({'2nd'},size(avg_exp_subj{2}{2},1),1)];
tbl_true={};
sub_true_distribution =[];
sub_ovrall_sig_05 = zeros(1,size(avg_exp_subj{2}{1},2));
sub_p_true = [];
    exp_per_sub = [];
    for k=1:2
        temp_hold = [];
        temp_hold = avg_exp_subj{k}{2};
        exp_per_sub = [exp_per_sub;  temp_hold];
    end

    for m=1:size(exp_per_sub,2)
        [sub_p_true(m), tbl_true{m}] = kruskalwallis(exp_per_sub(:,m),grouplabel,'off');
        sub_true_distribution(m) = tbl_true{m}{2,5};                   
    end
    %%%%%%%%%%%% FDR correction %%%%%%%%%%%%%%%%%%%%%%%

    [rank rnk_num]= sort(sub_p_true);
    adj_pval = ([1:size(rank,2)]./size(rank,2)).*0.1
    k = find(adj_pval <=0.05,1,'last')
    rank(k+1:end) = 1;
    
    ylim([0.78 1.1])
    ytick = yticks;
    xloc = find(sub_p_true <= 0.05);
    
        
%     plot(MorletBank(xloc),ytick(end)-0.02,'ks', 'MarkerSize',7);
    adj_p_align(rnk_num) = rank;
    xloc = find(adj_p_align <= 0.05);
    semilogx(MorletBank(xloc),ytick(end)-0.03*ones(size(xloc)),'color',color_code{2},'linewidth',2,'HandleVisibility','off');
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



h = gca; % Get axis to modify
h.XAxis.MinorTick = 'on'; % Must turn on minor ticks if they are off
h.XAxis.MinorTickValues = [4 6 7 8 9 40 60 70 80];
ylabel('Scaling exponent (\alpha)','interpreter','Tex','FontSize',12)
legend('Pre-sMCI','Pre-pMCI','Post-sMCI','Post-pMCI')
legend boxoff
xlim([2.2 90])
xticks([3 5 10 20 30 50 90]);
xticklabels([3 5 10 20 30 50 90])
box off
xlabel('Frequency (Hz)')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
clc

load('L:\nttk-data2\palva\Madrid\Full Cohort\Figures Codes\Standalone figure codes\Longitudinal_data_DFA_fEI.mat')

for k=1:2
    for grp = 1:size(temp_fEI{k},2)        
        for i=1:size(temp_fEI{k}{grp},3)
            if any(any(isnan(nanmean(temp_fEI{k}{grp}(:,:,i),1))))                
                temp_fEI{k}{grp}(:,:,i) = nanmean(temp_fEI{k}{grp},3);
            end
            avg_fEI_subj{k}{grp}(i,:) = nanmean(temp_fEI{k}{grp}(:,:,i));
        end
    end
end

for k=1:2
    for grp = 1:size(temp_fEI{k},2)        
        for i=1:size(temp_fEI{k}{grp},3)
            if any(any(isnan(temp_fEI{k}{grp}(:,:,i))))
                for j=1:size(temp_fEI{k}{grp},1)
                    if any(any(isnan(temp_fEI{k}{grp}(j,:,i))))
                        temp_fEI{k}{grp}(j,:,i) = nanmean(temp_fEI{k}{grp}(:,:,i),1);
                    end
                end
            end
            avg_fEI_subj{k}{grp}(i,:) = nanmean(temp_fEI{k}{grp}(:,:,i));
        end
    end
end


for k=1:2
    for grp = 1:size(temp_exp{k},2)        
        for i=1:size(temp_exp{k}{grp},3)
            avg_exp_subj{k}{grp}(i,:) = nanmean(temp_exp{k}{grp}(:,:,i));
        end
        if any(any(isnan(avg_fEI_subj{k}{grp})))
            nanindx(k,grp) = find(isnan(avg_fEI_subj{k}{grp}(:,1)))
            avg_fEI_subj{k}{grp}(nanindx(k,grp),:) = nanmean(avg_fEI_subj{k}{grp});
        end

    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cnct_exp=[];
cnct_fEI=[];
for k=1:size(avg_exp_subj,2)
    for j=1:size(avg_exp_subj{1},2)
        cnct_exp = [cnct_exp;avg_exp_subj{k}{j}];
        cnct_fEI = [cnct_fEI;avg_fEI_subj{k}{j}];
    end
end

Corr_fEI_DFA = [];
for i=1:size(avg_exp_subj{k}{j},2)
            [Corr_fEI_DFA(1,i) pval(1,i)]= corr(cnct_fEI(:,i),cnct_exp(:,i),'Type','Spearman');
end

color_code = {[0.3 0.44 1],[0 0.5 0],[1 0.44 0],[1 0 1],[0 0.5 0.5],[1 0.44 0.5]}; %{'b';'m';'g';'r'};%[0.47 0.47 1;1 0.53 0.1;0.56 0.82 0.56;1 0.48 0.48];
% % % figure
% % % subplot(211)
% % %     
% % %     semilogx(MorletBank,Corr_fEI_DFA,'color',[1 0.6 0.78],'linewidth',2)
% % %     hold on
% % %     
% % %     [rank rnk_num]= sort(pval);
% % %     adj_pval = ([1:size(rank,2)]./size(rank,2)).*0.1;
% % %     k = find(adj_pval <=0.05,1,'last')
% % %     rank(k+1:end) = 1;
% % %     adj_p_align(rnk_num) = rank;
% % %     
% % %     semilogx(MorletBank(find(adj_p_align < 0.05)),Corr_fEI_DFA(find(adj_p_align < 0.05)),'*','color',[1 0.6 0.78],'linewidth',2,'HandleVisibility','off')
% % % 
% % % xlim([2.2 90])
% % % xticks([2.2 5 10 20 30 50 90]);
% % % xticklabels([2 5 10 20 30 50 90])
% % % h = gca; % Get axis to modify
% % % h.XAxis.MinorTick = 'on'; % Must turn on minor ticks if they are off
% % % h.XAxis.MinorTickValues = [3 4 6 7 8 9 40 60 70 80];
% % % title('Average across parcels')
% % % % xlabel('Frequency (Hz)')
% % % ylabel('r (fE/I,DFA-exp)')
% % % box off
% % % set(gca,'FontSize', 10)
% % % legend('PreNCon','PreCon','PostNcon','PostCon')
% % % legend boxoff
% % % % legend('<NC>','<SCD>','<MCI>','p < 0.05','p < 0.05','p < 0.05')



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


for j=1:32   
    a=1;
    n=1;
    x_ax = [];
    y_ax = [];
    for k=1:2
        for m=1:2
             figure(1)
            subplot(4,2,n)
            y1=[];x1=[];
            x1 = mean(avg_exp_subj{k}{m}(:,j),2);
            y1 = mean(avg_fEI_subj{k}{m}(:,j),2);

            fit1= polyfit(y1(:),x1(:),1);
            val = polyval(fit1,y1(:));    
            hold on
            scatter(y1(:),x1(:),10,color_code{a})
            scatter(nanmean(y1(:)),nanmean(x1(:)),100,color_code{a},'filled')
            plot(y1(:),val(:),'color',color_code{a})
            [C pv]= corr(y1(:),x1(:),'Type','pearson');
            ylim([0.5 0.85]);
            xlim([0.4 1.1]);
            yax = ylim;
            xax = xlim;
            text(xax(1)+0.02,yax(2)-0.02,sprintf('r = %.2f, p = %.3f',C,pv),'HorizontalAlignment','left', 'Color', color_code{a})
            ylabel('DFA-exp')

            x_ax = [x_ax; y1];
            y_ax = [y_ax; x1];

            subplot(4,2,n+1)
            hold on
            [rho(a,j),p_rho(a,j)] = quad_fit_all_longitdnl(y1(:),x1(:),color_code{a},2,'fE/I','DFA-exp',logical(1),xax,yax,a);
            figure(2)
            [rho_all(j),p_rho_all(j)] = quad_fit_all_longitdnl(y1(:),x1(:),color_code{a},2,'fE/I','DFA-exp',logical(0),xax,yax,a);
            n=n+2;
            a=a+1;
        end
    end    
        [rho_all(j),p_rho_all(j)] = quad_fit_all_longitdnl(x_ax(:),y_ax(:),color_code{a},2,'fE/I','DFA-exp',logical(1),xax,yax,999);
        close all
end


figure
 %Linear   
    semilogx(MorletBank,Corr_fEI_DFA,'color',[1 0.6 0.78],'linewidth',2)
    hold on
    
    [rank rnk_num]= sort(pval);
    adj_pval = ([1:size(rank,2)]./size(rank,2)).*0.1;
    k = find(adj_pval <=0.05,1,'last')
    rank(k+1:end) = 1;
    adj_p_align(rnk_num) = rank;
    
    semilogx(MorletBank(find(adj_p_align < 0.05)),Corr_fEI_DFA(find(adj_p_align < 0.05)),'*','color',[1 0.6 0.78],'linewidth',2,'HandleVisibility','off')



% Quadratic
    semilogx(MorletBank,rho_all(:),'color',[0.87 0.49 0],'linewidth',2)
    hold on    
    [rank rnk_num]= sort(p_rho_all);
adj_pval = ([1:size(rank,2)]./size(rank,2)).*0.1;
k = find(adj_pval <=0.05,1,'last')
rank(k+1:end) = 1;
adj_p_align(rnk_num) = rank;
    semilogx(MorletBank(find(adj_p_align(:) < 0.05)),rho_all(find(adj_p_align(:) < 0.05)),'*','color',[0.87 0.49 0],'linewidth',3)
xlim([2.2 90])
xticks([2.2 5 10 20 30 50 90]);
xticklabels([2 5 10 20 30 50 90])
h = gca; % Get axis to modify
h.XAxis.MinorTick = 'on'; % Must turn on minor ticks if they are off
h.XAxis.MinorTickValues = [3 4 6 7 8 9 40 60 70 80];
ylabel('rho')
xlabel('Frequency (Hz)')
title('All groups')
set(gca,'FontSize', 12)
box off

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% % % %% within session delta(change) correlations between DFA and fE/I
% % % 
% % % color_code = {[0.3 0.44 1],[0 0.5 0],[1 0.44 0],[1 0 1],[0 0.5 0.5],[1 0.44 0.5]}; %{'b';'m';'g';'r'};%[0.47 0.47 1;1 0.53 0.1;0.56 0.82 0.56;1 0.48 0.48];
% % % 
% % % 
% % % cnct_exp={};
% % % cnct_fEI={};
% % % for k=1:size(avg_exp_subj,2)
% % %     cnct_exp{k} = avg_exp_subj{k}{2}-nanmean(avg_exp_subj{k}{1});
% % %     cnct_fEI{k} = avg_fEI_subj{k}{2}-nanmean(avg_fEI_subj{k}{1});
% % % end
% % % 
% % % Corr_fEI_DFA = [];
% % % for k=1:size(avg_exp_subj,2)
% % %     for i=1:size(avg_exp_subj{k}{1},2)
% % %         [Corr_fEI_DFA(k,i) pval(k,i)]= corr(cnct_fEI{k}(:,i),cnct_exp{k}(:,i),'Type','Pearson');
% % %     end
% % % end
% % % 
% % % 
% % % 
% % % figure
% % %  %Linear 
% % % for k=1:size(avg_exp_subj,2)  
% % %     semilogx(MorletBank,Corr_fEI_DFA(k,:),'color',color_code{k+3},'linewidth',2)
% % %     hold on
% % %     
% % %     [rank rnk_num]= sort(pval(k,:));
% % %     adj_pval = ([1:size(rank,2)]./size(rank,2)).*0.1;
% % %     lk = find(adj_pval <=0.05,1,'last')
% % %     rank(lk+1:end) = 1;
% % %     adj_p_align(rnk_num) = rank;
% % %     
% % %     semilogx(MorletBank(find(adj_p_align < 0.05)),Corr_fEI_DFA(k,find(adj_p_align < 0.05)),'*','color',color_code{k+3},'linewidth',2,'HandleVisibility','off')
% % % 
% % % end
% % % legend('Pre (pMCI - sMCI)','Post(pMCI - sMCI)')
% % % xlim([2.2 90])
% % % xticks([2.2 5 10 20 30 50 90]);
% % % xticklabels([2 5 10 20 30 50 90])
% % % h = gca; % Get axis to modify
% % % h.XAxis.MinorTick = 'on'; % Must turn on minor ticks if they are off
% % % h.XAxis.MinorTickValues = [3 4 6 7 8 9 40 60 70 80];
% % % ylabel('corr-coeff')
% % % xlabel('Frequency (Hz)')
% % % box off
% % % 
% % % band ={[6:11],[12:15],[16:22],[23:32]};
% % % 
% % % bndwise_exp={};
% % % bndwise_fEI={};
% % % for k=1:size(avg_exp_subj,2) 
% % %     for bnd =1:size(band,2)
% % %        bndwise_exp{k}(:,bnd) = nanmean(cnct_exp{k}(:,band{bnd}),2);
% % %        bndwise_fEI{k}(:,bnd) = nanmean(cnct_fEI{k}(:,band{bnd}),2);
% % %     end
% % % end
% % % 
% % % Corr_fEI_DFA_band = [];
% % % pval_band=[];
% % % for k=1:size(avg_exp_subj,2)
% % %     for i=1:size(bndwise_exp{k},2)
% % %         [Corr_fEI_DFA_band(k,i) pval_band(k,i)]= corr(bndwise_fEI{k}(:,i),bndwise_exp{k}(:,i),'Type','Pearson');
% % %     end
% % % end
% % % 
% % % 
% % % figure
% % %  %Linear
% % %  bnd = [1,2,3,4];
% % % for k=1:size(avg_exp_subj,2)  
% % %     plot(bnd,Corr_fEI_DFA_band(k,:),'color',color_code{k+3},'linewidth',2)
% % %     hold on 
% % %     
% % %     plot(bnd(1,find(pval_band(k,:) < 0.05)),Corr_fEI_DFA_band(k,find(pval_band(k,:) < 0.05)),'*','color',color_code{k+3},'linewidth',2,'HandleVisibility','off')
% % % 
% % % end
% % % legend('Pre (pMCI - sMCI)','Post(pMCI - sMCI)')
% % % xlim([0 5])
% % % xticks([1 2 3 4])
% % % xticklabels({'theta','alpha','beta','gamma'})
% % % xlabel('Frequency bands')
% % % ylabel('corr-coeff')
% % % 
% % % 
% % % %% between sessions
% % % 
% % % 
% % % cnct_exp={};
% % % cnct_fEI={};
% % % for k=1:size(avg_exp_subj,2)
% % %     cnct_exp{k} = avg_exp_subj{2}{k}-(avg_exp_subj{1}{k});
% % %     cnct_fEI{k} = avg_fEI_subj{2}{k}-(avg_fEI_subj{1}{k});
% % % end
% % % 
% % % Corr_fEI_DFA = [];
% % % pval =[];
% % % for k=1:size(avg_exp_subj,2)
% % %     for i=1:size(avg_exp_subj{k}{1},2)
% % %         [Corr_fEI_DFA(k,i) pval(k,i)]= corr(cnct_fEI{k}(:,i),cnct_exp{k}(:,i),'Type','Pearson');
% % %     end
% % % end
% % % 
% % % color_code = {[0.6 0.44 1],[1 0.5 0.3],[1 0.44 0],[0.7 0.5 1],[0.7 0.5 0.5],[1 0.44 0.5]}; %{'b';'m';'g';'r'};%[0.47 0.47 1;1 0.53 0.1;0.56 0.82 0.56;1 0.48 0.48];
% % % 
% % % 
% % % figure
% % %  %Linear 
% % % for k=1:size(avg_exp_subj,2)  
% % %     semilogx(MorletBank,Corr_fEI_DFA(k,:),'color',color_code{k+3},'linewidth',2)
% % %     hold on
% % %     
% % %     [rank rnk_num]= sort(pval(k,:));
% % %     adj_pval = ([1:size(rank,2)]./size(rank,2)).*0.1;
% % %     lk = find(adj_pval <=0.05,1,'last')
% % %     rank(lk+1:end) = 1;
% % %     adj_p_align(rnk_num) = rank;
% % %     
% % %     semilogx(MorletBank(find(adj_p_align < 0.05)),Corr_fEI_DFA(k,find(adj_p_align < 0.05)),'*','color',color_code{k+3},'linewidth',2,'HandleVisibility','off')
% % % 
% % % end
% % % legend('sMCI (post - pre)','pMCI (post - pre)')
% % % xlim([2.2 90])
% % % xticks([2.2 5 10 20 30 50 90]);
% % % xticklabels([2 5 10 20 30 50 90])
% % % h = gca; % Get axis to modify
% % % h.XAxis.MinorTick = 'on'; % Must turn on minor ticks if they are off
% % % h.XAxis.MinorTickValues = [3 4 6 7 8 9 40 60 70 80];
% % % ylabel('corr-coeff')
% % % xlabel('Frequency (Hz)')
% % % box off
% % % 
% % % band ={[6:11],[12:15],[16:22],[23:32]};
% % % 
% % % bndwise_exp={};
% % % bndwise_fEI={};
% % % for k=1:size(avg_exp_subj,2) 
% % %     for bnd =1:size(band,2)
% % %        bndwise_exp{k}(:,bnd) = nanmean(cnct_exp{k}(:,band{bnd}),2);
% % %        bndwise_fEI{k}(:,bnd) = nanmean(cnct_fEI{k}(:,band{bnd}),2);
% % %     end
% % % end
% % % 
% % % Corr_fEI_DFA_band = [];
% % % pval_band=[];
% % % for k=1:size(avg_exp_subj,2)
% % %     for i=1:size(bndwise_exp{k},2)
% % %         [Corr_fEI_DFA_band(k,i) pval_band(k,i)]= corr(bndwise_fEI{k}(:,i),bndwise_exp{k}(:,i),'Type','Pearson');
% % %     end
% % % end
% % % 
% % % 
% % % figure
% % %  %Linear
% % %  bnd = [1,2,3,4];
% % % for k=1:size(avg_exp_subj,2)  
% % %     plot(bnd,Corr_fEI_DFA_band(k,:),'color',color_code{k+3},'linewidth',2)
% % %     hold on 
% % %     
% % %     plot(bnd(1,find(pval_band(k,:) < 0.05)),Corr_fEI_DFA_band(k,find(pval_band(k,:) < 0.05)),'*','color',color_code{k+3},'linewidth',2,'HandleVisibility','off')
% % % 
% % % end
% % % legend('sMCI (post - pre)','pMCI (post - pre)')
% % % xlim([0 5])
% % % xticks([1 2 3 4])
% % % xticklabels({'theta','alpha','beta','gamma'})
% % % xlabel('Frequency bands')
% % % ylabel('corr-coeff')
% % % 
% % % 
%% within session prcl wise delta correlations between DFA and fE/I

band_label = {'alpha','beta'};
sess_label = {'Pre','Post'};

color_code = {[0.3 0.44 1],[0 0.5 0],[1 0.44 0],[1 0 1],[0 0.5 0.5],[1 0.44 0.5]}; %{'b';'m';'g';'r'};%[0.47 0.47 1;1 0.53 0.1;0.56 0.82 0.56;1 0.48 0.48];


cnct_exp_prcls={};
cnct_fEI_prcls={};
for k=1:size(temp_exp,2)
    for i=1:size(temp_exp{k}{2},3)
        cnct_exp_prcls{k}(:,:,i) = temp_exp{k}{2}(:,:,i)-nanmean(temp_exp{k}{1}(:,:,:),3);
        cnct_fEI_prcls{k}(:,:,i) = temp_fEI{k}{2}(:,:,i)-nanmean(temp_fEI{k}{1}(:,:,:),3);
    end
end

band ={[6:11],[12:15],[16:22],[23:32]};
band_exp_prcls = [];
band_fEI_prcls =[];
for bnd = 1:size(band,2)
    for k=1:2
        band_exp_prcls{bnd}{k}(:,:) = nanmean(cnct_exp_prcls{k}(:,band{bnd},:),2);
        band_fEI_prcls{bnd}{k}(:,:) = nanmean(cnct_fEI_prcls{k}(:,band{bnd},:),2);
    end
end

Corr_fEI_DFA_prcls = {};
pval_prcls ={};
for bnd = 1:size(band,2)
    for k=1:2
        for i=1:size(band_exp_prcls{bnd}{k},1)
            [Corr_fEI_DFA_prcls{bnd}(k,i) pval_prcls{bnd}(k,i)]= corr(band_fEI_prcls{bnd}{k}(i,:)',band_exp_prcls{bnd}{k}(i,:)','Type','Pearson');
        end
    end
end

sig=0.05;
Q = 0.2;
[fdr_sig_05_DFA_fEI]=fdr_correct_sig05([pval_prcls{2},pval_prcls{3}],sig,Q); numel(find(fdr_sig_05_DFA_fEI))

fdr_sig{2} = fdr_sig_05_DFA_fEI(:,1:400);
fdr_sig{3} = fdr_sig_05_DFA_fEI(:,401:800);

for bnd = 2:3
    fdr_sig{bnd}(find(fdr_sig{bnd}(:,:)==0)) = NaN;
    Corr_fdr_sig={};
    data=[];
    for k=1:size(avg_exp_subj,2)
        
        Corr_fdr_sig{1}{k} = (Corr_fEI_DFA_prcls{bnd}(k,:).*fdr_sig{bnd}(k,:))';
        data(:,k) = Corr_fdr_sig{1}{k};
        Corr_fdr_sig{1}{k}(isnan(Corr_fdr_sig{1}{k}))=[];
    end
        cases = {'Pre (pMCI - sMCI)','Post(pMCI - sMCI)'};
% % %         figure, pirateplot(Corr_fdr_sig{1},cases,0.95);
        
        figure        
        vcolor =[0 0 0.562500000000000;0.500000000000000 0 0];
        for i=1:2        
            x=data(:,i);
            vec_X =[1,2];
            xScat{i} = vec_X(i)*ones(1,length(x)) + 0.1*(rand(1,length(x))-0.5);
            hold on, scatter(xScat{i},x,floor(40/2),'filled',...
                'MarkerFaceColor',vcolor(i,:), 'MarkerEdgeColor',[0,0,0],...
                'MarkerFaceAlpha',0.15,'MarkerEdgeAlpha',0.15);        
        end    
        boxplot(data, vec_X);
        xticklabels(cases)        
data2=[];
data2=data;
data2(isnan(data2)) = 0;
load('L:\nttk-data2\palva\Madrid\Codes 18-2-2020\DFA Code new\Figure Codes and data\py_aligned_network_for_inflated_surface_plot.mat')
alpha_diff11{bnd} = data2(:,1);
alpha_diff11{bnd}= alpha_diff11{bnd}(py_aligned_network);
fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Figures Codes\Paper-figures codes\Figure_7_inflated_surface_data\Pre_' band_label{bnd-1} '_diff11.csv' ];
%         csvwrite(fname,alpha_diff11{bnd})
beta_diff11{bnd} = data2(:,2);
beta_diff11{bnd}= beta_diff11{bnd}(py_aligned_network);
fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Figures Codes\Paper-figures codes\Figure_7_inflated_surface_data\Post_' band_label{bnd-1} '_diff11.csv' ];
%         csvwrite(fname,beta_diff11{bnd})
end        


sess_label = {'sMCI','pMCI'};
%% between session prcl wise delta correlations between DFA and fE/I

color_code = {[0.3 0.44 1],[0 0.5 0],[1 0.44 0],[1 0 1],[0 0.5 0.5],[1 0.44 0.5]}; %{'b';'m';'g';'r'};%[0.47 0.47 1;1 0.53 0.1;0.56 0.82 0.56;1 0.48 0.48];


cnct_exp_prcls={};
cnct_fEI_prcls={};
for k=1:size(temp_exp,2)
    for i=1:size(temp_exp{k}{1},3)
        cnct_exp_prcls{k}(:,:,i) = temp_exp{2}{k}(:,:,i)-nanmean(temp_exp{1}{k}(:,:,:),3);
        cnct_fEI_prcls{k}(:,:,i) = temp_fEI{2}{k}(:,:,i)-nanmean(temp_fEI{1}{k}(:,:,:),3);
    end
end

band ={[6:11],[12:15],[16:22],[23:32]};
band_exp_prcls = [];
band_fEI_prcls =[];
for bnd = 1:size(band,2)
    for k=1:2
        band_exp_prcls{bnd}{k}(:,:) = nanmean(cnct_exp_prcls{k}(:,band{bnd},:),2);
        band_fEI_prcls{bnd}{k}(:,:) = nanmean(cnct_fEI_prcls{k}(:,band{bnd},:),2);
    end
end

Corr_fEI_DFA_prcls = {};
pval_prcls ={};
for bnd = 1:size(band,2)
    for k=1:2
        for i=1:size(band_exp_prcls{bnd}{k},1)
            [Corr_fEI_DFA_prcls{bnd}(k,i) pval_prcls{bnd}(k,i)]= corr(band_fEI_prcls{bnd}{k}(i,:)',band_exp_prcls{bnd}{k}(i,:)','Type','Pearson');
        end
    end
end

sig=0.05;
Q = 0.2;
[fdr_sig_05_DFA_fEI]=fdr_correct_sig05([pval_prcls{2},pval_prcls{3}],sig,Q); numel(find(fdr_sig_05_DFA_fEI))

fdr_sig{2} = fdr_sig_05_DFA_fEI(:,1:400);
fdr_sig{3} = fdr_sig_05_DFA_fEI(:,401:800);

for bnd = 2:3
    fdr_sig{bnd}(find(fdr_sig{bnd}(:,:)==0)) = NaN;
    Corr_fdr_sig={};
    data=[];
    for k=1:size(avg_exp_subj,2)
        
        Corr_fdr_sig{1}{k} = (Corr_fEI_DFA_prcls{bnd}(k,:).*fdr_sig{bnd}(k,:))';
        data(:,k) = Corr_fdr_sig{1}{k};
        Corr_fdr_sig{1}{k}(isnan(Corr_fdr_sig{1}{k}))=[];
    end
        cases = {'sMCI (post - pre)','pMCI(post - pre)'};
% % %         figure, pirateplot(Corr_fdr_sig{1},cases,0.95);
        
        figure        
        vcolor =[0 0 0.562500000000000;0.500000000000000 0 0];
        for i=1:2        
            x=data(:,i);
            vec_X =[1,2];
            xScat{i} = vec_X(i)*ones(1,length(x)) + 0.1*(rand(1,length(x))-0.5);
            hold on, scatter(xScat{i},x,floor(40/2),'filled',...
                'MarkerFaceColor',vcolor(i,:), 'MarkerEdgeColor',[0,0,0],...
                'MarkerFaceAlpha',0.15,'MarkerEdgeAlpha',0.15);        
        end    
        boxplot(data, vec_X);
        xticklabels(cases)
        ylim([-0.8 0.8])


data2=data;
data2(isnan(data2)) = 0;
alpha_diff12={};
beta_diff12={};
load('L:\nttk-data2\palva\Madrid\Codes 18-2-2020\DFA Code new\Figure Codes and data\py_aligned_network_for_inflated_surface_plot.mat')
alpha_diff12 = data2(:,1);
alpha_diff12= alpha_diff12(py_aligned_network);
fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Figures Codes\Paper-figures codes\Figure_7_inflated_surface_data\sMCI_' band_label{bnd-1} '_diff12.csv' ];
%         csvwrite(fname,alpha_diff12)
beta_diff12 = data2(:,2);
beta_diff12= beta_diff12(py_aligned_network);
fname = ['L:\nttk-data2\palva\Madrid\Full Cohort\Figures Codes\Paper-figures codes\Figure_7_inflated_surface_data\pMCI_' band_label{bnd-1} '_diff12.csv' ];
%         csvwrite(fname,beta_diff12)

        
end
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Corr_fEI_DFA_all = []; pval_all= [];
for bnd = 2:3
    cnct_exp=[];
    cnct_fEI=[];
    for k=1:size(avg_exp_subj,2)
        for j=1:size(avg_exp_subj{1},2)
            ttmp=[];
            ttmp(:,:) = nanmean(temp_exp{k}{j}(:,band{bnd},:),2);
            cnct_exp = [cnct_exp,ttmp];
            ttmp=[];
            ttmp(:,:) = nanmean(temp_fEI{k}{j}(:,band{bnd},:),2);
            cnct_fEI = [cnct_fEI,ttmp];
        end
    end


    for i=1:size(cnct_exp,1)
        [Corr_fEI_DFA_all(bnd-1,i) pval_all(bnd-1,i)]= corr(cnct_fEI(i,:)',cnct_exp(i,:)','Type','Spearman');
    end
end

sig=0.05;
Q = 0.05;
[fdr_sig_05_DFA_fEI]=fdr_correct_sig05(pval_all,sig,Q); numel(find(fdr_sig_05_DFA_fEI))
fdr_sig_05_DFA_fEI(fdr_sig_05_DFA_fEI==0) = NaN;

data1=[];
data1=Corr_fEI_DFA_all;

data2={};
data1 = data1.*fdr_sig_05_DFA_fEI;
data = data1';
for i=1:size(data,2)
    temp=[]; temp = data(:,i);
    temp(isnan(temp)) = [];
    data2{i} = temp;            
end

figure        
vcolor =[0 0 0.562500000000000;0.500000000000000 0 0];
for i=1:2        
    x=data2{:,i};
    vec_X =[1,2];
    xScat{i} = vec_X(i)*ones(1,length(x)) + 0.1*(rand(1,length(x))-0.5);
    hold on, scatter(xScat{i},x,floor(40/2),'filled',...
        'MarkerFaceColor',vcolor(i,:), 'MarkerEdgeColor',[0,0,0],...
        'MarkerFaceAlpha',0.15,'MarkerEdgeAlpha',0.15);        
end    
boxplot(data, vec_X);
xticklabels({'Alpha','Beta'}) 
ylabel('corr(LRTC,fE/I)')

labl={'Alpha','Beta'};
    figure
    vcolor =[0.5 0.3 0.562500000000000;0.500000000000000 0.4 0.1];
    for i=1:size(data,2)
        x=data2{:,i};
        subplot(1,2,i)

        yaxis_val = raincloud_yaxis(x(:));
        raincloud_plot_color(round(x(:),2),yaxis_val, vcolor(i,:));        
        xlim([-0.6 -0.1])
        camroll(90)
        x1 = get(gca,'XLim');
        yl = get(gca,'YLim');
        set(gca,'YLim',[-yl(2)-5 yl(2)+3]);
        ylabel(labl{i})
    end
xlabel('corr(LRTC,fE/I)')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
clc


load('L:\nttk-data2\palva\Madrid\Full Cohort\Figures Codes\Standalone figure codes\Longitudinal_data_DFA_fEI.mat')
for k=1:2
    for grp = 1:2
        for i=1:size(temp_exp{k}{grp},3)
            avg_exp_subj{k}{grp}(i,:) = nanmean(temp_exp{k}{grp}(:,:,i));
        end
    end
end

for m=1:2
    for k=1:2
        MMSE{m,k}(find(isnan(MMSE{m,k})))=round(nanmean(MMSE{m,k}));
    end
end


%% within session prcl wise delta correlations between DFA and MMSE

color_code = {[0.3 0.44 1],[0 0.5 0],[1 0.44 0],[1 0 1],[0 0.5 0.5],[1 0.44 0.5]}; %{'b';'m';'g';'r'};%[0.47 0.47 1;1 0.53 0.1;0.56 0.82 0.56;1 0.48 0.48];


cnct_exp_prcls={};
cnct_MMSE={};
for k=1:size(temp_exp,2)
    for i=1:size(temp_exp{k}{2},3)
        cnct_exp_prcls{k}(:,:,i) = temp_exp{k}{2}(:,:,i)-nanmean(temp_exp{k}{1}(:,:,:),3);
        cnct_MMSE{k}(i) = MMSE{k,2}(i)-nanmean(MMSE{k,1});
    end
end

band ={[6:11],[12:15],[16:22],[23:32]};
band_exp_prcls = [];
for bnd = 1:size(band,2)
    for k=1:2
        band_exp_prcls{bnd}{k}(:,:) = nanmean(cnct_exp_prcls{k}(:,band{bnd},:),2);
    end
end

Corr_fEI_DFA_prcls = {};
pval_prcls ={};
for bnd = 1:size(band,2)
    for k=1:2
        for i=1:size(band_exp_prcls{bnd}{k},1)
            [Corr_fEI_DFA_prcls{bnd}(k,i) pval_prcls{bnd}(k,i)]= corr(cnct_MMSE{k}(:),band_exp_prcls{bnd}{k}(i,:)','Type','Pearson');
        end
    end
end

sig=0.05;
Q = 0.2;
[fdr_sig_05_DFA_fEI]=fdr_correct_sig05([pval_prcls{2},pval_prcls{3}],sig,Q); numel(find(fdr_sig_05_DFA_fEI))

fdr_sig{2} = fdr_sig_05_DFA_fEI(:,1:400);
fdr_sig{3} = fdr_sig_05_DFA_fEI(:,401:800);

for bnd = 2:3
    fdr_sig{bnd}(find(fdr_sig{bnd}(:,:)==0)) = NaN;
    Corr_fdr_sig={};
    data=[];
    for k=1:size(avg_exp_subj,2)
        
        Corr_fdr_sig{1}{k} = (Corr_fEI_DFA_prcls{bnd}(k,:).*fdr_sig{bnd}(k,:))';
        data(:,k) = Corr_fdr_sig{1}{k};
        Corr_fdr_sig{1}{k}(isnan(Corr_fdr_sig{1}{k}))=[];
    end
        cases = {'Pre (pMCI - sMCI)','Post(pMCI - sMCI)'};
% % %         figure, pirateplot(Corr_fdr_sig{1},cases,0.95);
        
        figure        
        vcolor =[0 0 0.562500000000000;0.500000000000000 0 0];
        for i=1:2        
            x=data(:,i);
            vec_X =[1,2];
            xScat{i} = vec_X(i)*ones(1,length(x)) + 0.1*(rand(1,length(x))-0.5);
            hold on, scatter(xScat{i},x,floor(40/2),'filled',...
                'MarkerFaceColor',vcolor(i,:), 'MarkerEdgeColor',[0,0,0],...
                'MarkerFaceAlpha',0.15,'MarkerEdgeAlpha',0.15);        
        end    
        boxplot(data, vec_X);
        xticklabels(cases)
        ylim([0.4 0.7])
end



%% between session prcl wise delta correlations between DFA and MMSE

color_code = {[0.3 0.44 1],[0 0.5 0],[1 0.44 0],[1 0 1],[0 0.5 0.5],[1 0.44 0.5]}; %{'b';'m';'g';'r'};%[0.47 0.47 1;1 0.53 0.1;0.56 0.82 0.56;1 0.48 0.48];


cnct_exp_prcls={};
cnct_MMSE={};
for k=1:size(temp_exp,2)
    for i=1:size(temp_exp{k}{1},3)
        cnct_exp_prcls{k}(:,:,i) = temp_exp{2}{k}(:,:,i)-nanmean(temp_exp{1}{k}(:,:,:),3);
        cnct_MMSE{k}(i) = MMSE{2,k}(i)-nanmean(MMSE{1,k});
    end
end

band ={[6:11],[12:15],[16:22],[23:32]};
band_exp_prcls = [];
band_fEI_prcls =[];
for bnd = 1:size(band,2)
    for k=1:2
        band_exp_prcls{bnd}{k}(:,:) = nanmean(cnct_exp_prcls{k}(:,band{bnd},:),2);
    end
end

Corr_fEI_DFA_prcls = {};
pval_prcls ={};
for bnd = 1:size(band,2)
    for k=1:2
        for i=1:size(band_exp_prcls{bnd}{k},1)
            [Corr_fEI_DFA_prcls{bnd}(k,i) pval_prcls{bnd}(k,i)]= corr(cnct_MMSE{k}(:),band_exp_prcls{bnd}{k}(i,:)','Type','Pearson');
        end
    end
end

sig=0.05;
Q = 0.2;
[fdr_sig_05_DFA_fEI]=fdr_correct_sig05([pval_prcls{2},pval_prcls{3}],sig,Q); numel(find(fdr_sig_05_DFA_fEI))

fdr_sig{2} = fdr_sig_05_DFA_fEI(:,1:400);
fdr_sig{3} = fdr_sig_05_DFA_fEI(:,401:800);

for bnd = 2:3
    fdr_sig{bnd}(find(fdr_sig{bnd}(:,:)==0)) = NaN;
    Corr_fdr_sig={};
    data=[];
    for k=1:size(avg_exp_subj,2)
        
        Corr_fdr_sig{1}{k} = (Corr_fEI_DFA_prcls{bnd}(k,:).*fdr_sig{bnd}(k,:))';
        data(:,k) = Corr_fdr_sig{1}{k};
        Corr_fdr_sig{1}{k}(isnan(Corr_fdr_sig{1}{k}))=[];
    end
        cases = {'sMCI (post - pre)','pMCI(post - pre)'};
% % %         figure, pirateplot(Corr_fdr_sig{1},cases,0.95);
        
        figure        
        vcolor =[0 0 0.562500000000000;0.500000000000000 0 0];
        for i=1:2        
            x=data(:,i);
            vec_X =[1,2];
            xScat{i} = vec_X(i)*ones(1,length(x)) + 0.1*(rand(1,length(x))-0.5);
            hold on, scatter(xScat{i},x,floor(40/2),'filled',...
                'MarkerFaceColor',vcolor(i,:), 'MarkerEdgeColor',[0,0,0],...
                'MarkerFaceAlpha',0.15,'MarkerEdgeAlpha',0.15);        
        end    
        boxplot(data, vec_X);
        xticklabels(cases)
        ylim([0.4 0.7])
        box off
end


%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Corr_fEI_DFA_all = []; pval_all= [];
for bnd = 2:3
    cnct_exp=[];
    cnct_MMSE=[];
    for k=1:size(avg_exp_subj,2)
        for j=1:size(avg_exp_subj{1},2)
            ttmp=[];
            ttmp(:,:) = nanmean(temp_exp{k}{j}(:,band{bnd},:),2);
            cnct_exp = [cnct_exp,ttmp];
            ttmp=[];
            ttmp(1,:) = MMSE{k,j};
            cnct_MMSE = [cnct_MMSE,ttmp];
        end
    end


    for i=1:size(cnct_exp,1)
        [Corr_fEI_DFA_all(bnd-1,i) pval_all(bnd-1,i)]= corr(cnct_MMSE',cnct_exp(i,:)','Type','Spearman');
    end
end

sig=0.05;
Q = 0.05;
[fdr_sig_05_DFA_fEI]=fdr_correct_sig05(pval_all,sig,Q); numel(find(fdr_sig_05_DFA_fEI))
fdr_sig_05_DFA_fEI(fdr_sig_05_DFA_fEI==0) = NaN;

data1=[];
data1=Corr_fEI_DFA_all;


data1 = data1.*fdr_sig_05_DFA_fEI;
data = data1';
for i=1:size(data,2)
            temp=[]; temp = data(:,i);
            temp(isnan(temp)) = [];
            data2{i} = temp;            
end

figure        
vcolor =[0 0 0.562500000000000;0.500000000000000 0 0];
for i=1:2        
    x=data2{:,i};
    vec_X =[1,2];
    xScat{i} = vec_X(i)*ones(1,length(x)) + 0.1*(rand(1,length(x))-0.5);
    hold on, scatter(xScat{i},x,floor(40/2),'filled',...
        'MarkerFaceColor',vcolor(i,:), 'MarkerEdgeColor',[0,0,0],...
        'MarkerFaceAlpha',0.15,'MarkerEdgeAlpha',0.15);        
end    
boxplot(data, vec_X);
xticklabels({'Alpha','Beta'}) 
ylabel('corr(LRTC,MMSE)')


labl={'Alpha','Beta'};
    figure
    vcolor =[0.5 0.3 0.562500000000000;0.500000000000000 0.4 0.1];
    for i=1:size(data,2)
        x=data2{:,i};
        subplot(1,2,i)

        yaxis_val = raincloud_yaxis(x(:));
        raincloud_plot_color(round(x(:),2),yaxis_val, vcolor(i,:));        
        xlim([0.2 0.5])
        camroll(90)
        x1 = get(gca,'XLim');
        yl = get(gca,'YLim');
        set(gca,'YLim',[-yl(2)-5 yl(2)+3]);
        ylabel(labl{i})
    end
xlabel('corr(LRTC,MMSE)')


















